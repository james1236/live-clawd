(() => {
  // src/fiber.js
  function findComponentNode(names, raw, visible2) {
    if (!names || !names.length) return null;
    const want = new Set(names);
    let rootFiber = null;
    for (const n of [document.getElementById("root"), document.getElementById("app"), document.body, ...document.body ? document.body.children : []]) {
      const w = raw(n);
      if (!w) continue;
      let key;
      try {
        key = Object.keys(w).find((k) => k.startsWith("__reactContainer$"));
      } catch {
      }
      if (key) {
        rootFiber = w[key];
        break;
      }
    }
    if (!rootFiber) return null;
    const nameOf = (f) => {
      const t = f && f.type;
      if (!t || typeof t === "string") return "";
      return t.displayName || t.name || t.render && (t.render.displayName || t.render.name) || t.type && (t.type.displayName || t.type.name) || "";
    };
    const hostNode = (f) => {
      for (let q = f, i = 0; q && i < 200; i++) {
        if (q.tag === 5 && q.stateNode && visible2(q.stateNode)) return q.stateNode;
        q = q.child || (q === f ? null : nextOf(q, f));
      }
      return null;
    };
    const nextOf = (q, stop) => {
      while (q && q !== stop) {
        if (q.sibling) return q.sibling;
        q = q.return;
      }
      return null;
    };
    const found = /* @__PURE__ */ new Map();
    const stack = [rootFiber.current || rootFiber];
    for (let seen = 0; stack.length && seen < 3e4 && found.size < want.size; seen++) {
      const f = stack.pop();
      if (!f) continue;
      const nm = nameOf(f);
      if (want.has(nm) && !found.has(nm)) {
        const n = hostNode(f.child || f);
        if (n) found.set(nm, n);
      }
      if (f.sibling) stack.push(f.sibling);
      if (f.child) stack.push(f.child);
    }
    for (const nm of names) if (found.has(nm)) return found.get(nm);
    return null;
  }

  // src/probe.js
  var visible = (n) => {
    if (!n || !n.getBoundingClientRect) return false;
    const r = n.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) return false;
    const cs = getComputedStyle(n);
    return cs.visibility !== "hidden" && cs.display !== "none";
  };
  if (!window.__clawdProbe) {
    window.__clawdProbe = true;
    document.addEventListener("clawd-find", (e) => {
      try {
        const { names, token } = JSON.parse(e.detail);
        const n = findComponentNode(names, (x) => x, visible);
        if (n) n.setAttribute("data-clawd-found", token);
      } catch {
      }
    });
  }
})();
