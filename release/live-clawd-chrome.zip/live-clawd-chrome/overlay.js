(() => {
  // src/clawd-art.js
  var VIEWBOX = { x: -5, y: -8, w: 26, h: 19 };
  var R = (x, y, width, height, fill, cls) => ["rect", { x, y, width, height, fill, class: cls }];
  var C = (cx, cy, r, fill, cls, extra) => ["circle", { cx, cy, r, fill, class: cls, ...extra }];
  var T = (x, y, size, fill, text, cls) => ["text", {
    x,
    y,
    "font-size": size,
    fill,
    class: cls,
    "font-family": "system-ui, sans-serif",
    "font-weight": 700
  }, [text]];
  var G = (cls, children) => ["g", { class: cls }, children];
  var BODY = "var(--clawd, #d97757)";
  var EYE = "var(--clawd-eye, #1f1e1d)";
  var PAINT = "var(--paint, #d97757)";
  var WOOD = "#8a5a3c";
  var STEEL = "#9aa0a8";
  var DARK = "#2b2b2b";
  var PAPER = "#fbfaf6";
  var INK = "#b9b5aa";
  function heart(x, y, s, cls) {
    const px = [];
    [".#.#.", "#####", ".###.", "..#.."].forEach((row, j) => [...row].forEach((c, i) => {
      if (c === "#") px.push(R(x + i * s, y + j * s, s, s, "#e8636f"));
    }));
    return G(cls, px);
  }
  var RIGHT = [
    G("cw-prop cw-p-brush", [R(15, 1, 1, 4, WOOD), R(14.5, 0, 2, 1, STEEL), R(14.5, -2, 2, 2, PAINT)]),
    G("cw-prop cw-p-spray", [
      R(15, 0, 2, 4.5, "#7d8fa8"),
      R(15, 1.2, 2, 1, PAINT),
      R(15.5, -1, 1, 1, DARK),
      C(17.8, -1, 0.35, PAINT, "cw-mist"),
      C(18.8, -1.6, 0.3, PAINT, "cw-mist cw-m2"),
      C(18.6, -0.3, 0.3, PAINT, "cw-mist cw-m3"),
      C(19.6, -1, 0.25, PAINT, "cw-mist cw-m2")
    ]),
    G("cw-prop cw-p-eraser", [R(15, 1, 3, 3, "#f2a7b5"), R(15, 3, 3, 1, "#6f8fc0")]),
    G("cw-prop cw-p-pencil", [R(15, 0, 1, 4, "#f2c94c"), R(15, 4, 1, 1, "#e9b38a"), R(15, -1, 1, 1, "#f28b9b")]),
    G("cw-prop cw-p-hammer", [R(15, -1, 1, 6, WOOD), R(13.5, -2, 4, 2, "#6b7078")]),
    G("cw-prop cw-p-wrench", [R(15, 0, 1, 5, STEEL), R(14, -2, 1, 2, STEEL), R(16, -2, 1, 2, STEEL), R(14, -1, 3, 1, STEEL)]),
    G("cw-prop cw-p-glass", [
      ["line", { x1: 15, y1: 5, x2: 16.2, y2: 2.6, stroke: WOOD, "stroke-width": 0.9 }],
      C(17.2, 1, 1.9, "rgba(190,225,255,.55)", null, { stroke: "#5b6068", "stroke-width": 0.6 })
    ]),
    G("cw-prop cw-p-paper", [R(14, 0, 4, 5, PAPER), R(14.5, 1, 3, 0.5, INK), R(14.5, 2, 3, 0.5, INK), R(14.5, 3, 2, 0.5, INK)]),
    G("cw-prop cw-p-tape", [R(15, 3, 3, 3, "#f2c94c"), R(15.8, 3.8, 1.4, 1.4, DARK), R(18, 4.4, 4, 0.7, "#f7e08a", "cw-tape")]),
    G("cw-prop cw-p-camera", [
      R(14.5, 1, 4.5, 3, "#3b3b3b"),
      R(15, 0.4, 1.4, 0.6, "#3b3b3b"),
      C(16.8, 2.5, 1, "#8ab4d8", null, { stroke: "#222", "stroke-width": 0.3 }),
      R(17.8, 1.3, 0.8, 0.5, "#fff6c4", "cw-flashbulb")
    ]),
    G("cw-prop cw-p-sponge", [R(15, 2, 3, 2.2, "#f5d061"), R(15.5, 2.5, 0.5, 0.5, "#d9ae35"), R(16.8, 3.3, 0.5, 0.5, "#d9ae35")]),
    G("cw-prop cw-p-sign", [R(15.5, 1, 0.8, 4, WOOD), R(14, -3.2, 5.5, 4.2, PAPER), T(14.4, 0, 3, "#1f1e1d", "Aa", "cw-sign-text")]),
    G("cw-prop cw-p-hose", [
      ["path", { d: "M15.5 5.5 C 15.6 8.5, 17.2 9.2, 17.6 7", fill: "none", stroke: "#666", "stroke-width": 0.8 }],
      R(15.1, 0.6, 0.8, 5, "#888"),
      R(13.6, -0.6, 3.8, 1.3, "#d9534f"),
      R(13.6, -0.6, 3.8, 0.4, "#2b2b2b")
    ]),
    G("cw-prop cw-p-bottle", [
      R(15, -3, 2.2, 6, "rgba(120,190,240,.9)"),
      R(15, -3, 2.2, 1.6, "rgba(255,255,255,.35)", "cw-water-air"),
      R(15.4, -4, 1.4, 1, "#3a7bd5"),
      R(15, 0, 2.2, 1, "#ffffff")
    ]),
    G("cw-prop cw-p-ask", [R(15.6, 1, 0.8, 4.5, WOOD), R(13.8, -4.4, 6, 5, "#fff3c4"), R(13.8, -4.4, 6, 0.6, "#e2b04a"), T(14.9, -0.5, 3.4, "#c0392b", "!?", "cw-sign-text")]),
    G("cw-prop cw-p-plane", [
      ["polygon", { points: "14,1.4 20.4,-0.6 15.6,2.8", fill: PAPER, stroke: "#bdb8ac", "stroke-width": 0.2, class: "cw-plane" }]
    ]),
    G("cw-prop cw-p-timer", [C(16.2, 2.6, 1.7, "#e0533f"), R(15.8, 0.5, 0.8, 0.6, "#4caf6a"), R(16, 1.2, 0.4, 1.4, PAPER, "cw-dial")]),
    G("cw-prop cw-p-tube", [
      R(15.2, -2, 1.5, 5.4, "rgba(225,242,255,.75)"),
      R(15.2, 0.6, 1.5, 2.8, "#5ccf6a"),
      R(15, -2.3, 1.9, 0.5, "#c9d6e2"),
      C(15.9, -2.8, 0.35, "#9be6a6", "cw-bub"),
      C(16.4, -3.6, 0.3, "#9be6a6", "cw-bub cw-bub2"),
      C(15.6, -4.2, 0.25, "#9be6a6", "cw-bub cw-bub3")
    ]),
    G("cw-prop cw-p-key", [C(16, 0.5, 1.2, "#e2b04a"), C(16, 0.5, 0.45, "#8a6a1f"), R(15.6, 1.5, 0.8, 3.5, "#e2b04a"), R(16.4, 3.5, 0.8, 0.5, "#e2b04a")])
  ];
  var LEFT = [
    G("cw-lprop cw-l-palette", [
      ["ellipse", { cx: -0.7, cy: 4.6, rx: 2.6, ry: 1.7, fill: "#e8cfa0" }],
      C(-2, 4, 0.45, "#e05a4f"),
      C(-0.8, 3.6, 0.45, "#3d7fd6"),
      C(0.4, 4.1, 0.45, "#f2c94c"),
      C(-1.4, 5.3, 0.45, "#4caf6a"),
      C(0.1, 5.4, 0.45, PAINT)
    ]),
    G("cw-lprop cw-l-clipboard", [
      R(-3, 0.5, 4.5, 6, "#a9773f"),
      R(-2.6, 1.3, 3.7, 4.9, PAPER),
      R(-1.4, 0.1, 1.4, 0.8, STEEL),
      ...[0, 1, 2].flatMap((i) => [
        R(-2.2, 2 + i * 1.4, 0.8, 0.8, "#d8d3c6"),
        R(-1.1, 2.25 + i * 1.4, 1.9, 0.35, INK),
        R(-2.3, 2.2 + i * 1.4, 0.35, 0.5, "#3a9a52", `cw-chk cw-c${i}`),
        R(-2, 1.75 + i * 1.4, 0.35, 0.95, "#3a9a52", `cw-chk cw-c${i}`)
      ])
    ]),
    G("cw-lprop cw-l-flask", [
      R(-1.2, 1.4, 1.2, 2, "rgba(225,242,255,.75)"),
      C(-0.6, 4.5, 1.7, "rgba(225,242,255,.75)"),
      C(-0.6, 4.9, 1.25, "#b46be0"),
      C(-0.9, 4.4, 0.3, "#e0b9f5", "cw-bub"),
      C(-0.2, 3.6, 0.25, "#e0b9f5", "cw-bub cw-bub2")
    ]),
    G("cw-lprop cw-l-chalk", [R(0.7, 2.6, 0.7, 1.6, "#f4f1e8"), R(0.7, 2.6, 0.7, 0.4, "#d9d4c6")]),
    G("cw-lprop cw-l-notepad", [R(-2.5, 1.5, 3.5, 4.5, PAPER), R(-2.5, 1.5, 3.5, 0.7, "#e05a4f"), R(-2, 3, 2.5, 0.4, INK), R(-2, 4, 2.5, 0.4, INK)])
  ];
  var HEAD = [
    G("cw-hat cw-h-hardhat", [R(4, -2.2, 8, 2.2, "#f2c94c"), R(2.6, -0.4, 10.8, 0.9, "#e0b43a"), R(7.6, -2.2, 0.8, 2.2, "#e0b43a")]),
    G("cw-hat cw-h-goggles", [
      R(3, 1.5, 10, 0.6, "#5d636b"),
      R(4, 1, 3, 2.6, "rgba(170,220,255,.55)"),
      R(9, 1, 3, 2.6, "rgba(170,220,255,.55)"),
      R(4, 1, 3, 0.4, "#8a9099"),
      R(9, 1, 3, 0.4, "#8a9099")
    ]),
    G("cw-hat cw-h-shades", [R(4, 1.6, 3, 1.8, "#111"), R(9, 1.6, 3, 1.8, "#111"), R(7, 2, 2, 0.5, "#111"), R(4.4, 1.9, 0.8, 0.4, "#666")]),
    G("cw-hat cw-h-binos", [
      R(4, 1.2, 3, 2.8, "#333"),
      R(9, 1.2, 3, 2.8, "#333"),
      R(7, 2, 2, 1, "#333"),
      C(5.5, 2.6, 0.9, "#7fb0d6"),
      C(10.5, 2.6, 0.9, "#7fb0d6")
    ]),
    G("cw-hat cw-h-phones", [R(3.6, -1.2, 8.8, 0.8, "#333"), R(2.4, 0.6, 1.4, 3, "#333"), R(12.2, 0.6, 1.4, 3, "#333"), R(2.6, -0.8, 0.8, 1.6, "#333"), R(12.6, -0.8, 0.8, 1.6, "#333")]),
    G("cw-hat cw-h-beret", [["ellipse", { cx: 7, cy: -0.4, rx: 4.2, ry: 1.2, fill: "#3b3b6b" }], R(6.6, -1.9, 0.8, 0.8, "#3b3b6b")])
  ];
  var OVERHEAD = [
    G("cw-over cw-o-block", [R(4.5, -4.5, 7, 4, PAPER), R(4.5, -4.5, 7, 0.6, BODY), R(7.5, -3.4, 1, 2, BODY), R(7, -2.9, 2, 1, BODY)]),
    G("cw-over cw-o-parcel", [R(4.5, -4.5, 7, 4, "#c79a62"), R(7.5, -4.5, 1, 4, "#a77c48")]),
    G("cw-over cw-o-chest", [R(4.5, -4.5, 7, 4, "#a0672f"), R(4.5, -3.2, 7, 0.5, "#e2b04a"), R(7.5, -3.5, 1, 1.2, "#e2b04a"), R(4.5, -4.5, 7, 0.5, "#7d4f22")])
  ];
  var CHALK = "#e9efe6";
  var TWIN = G("cw-front cw-b-twin", [
    R(4, 8, 1, 2, BODY),
    R(6, 8, 1, 2, BODY),
    R(9, 8, 1, 2, BODY),
    R(11, 8, 1, 2, BODY),
    R(3, 0, 10, 8, BODY),
    R(1, 4, 2, 2, BODY),
    R(13, 4, 2, 2, BODY),
    R(5, 2, 1, 2, EYE),
    R(10, 2, 1, 2, EYE)
  ]);
  var BOARD = G("cw-front cw-b-board", [
    R(-4.8, -6.8, 25.6, 9.1, WOOD),
    R(-4.5, -6.5, 25, 8.5, "#2f4f3a"),
    R(-3.6, 2.3, 0.6, 7.7, WOOD),
    R(19.6, 2.3, 0.6, 7.7, WOOD),
    T(-3.6, -3.4, 2.2, CHALK, "x\xB2+y", "cw-chalk cw-k0"),
    R(-3.6, -2.6, 5, 0.25, CHALK, "cw-chalk cw-k0"),
    T(3.4, -4.2, 2, CHALK, "\u2211 n\xB7k", "cw-chalk cw-k1"),
    T(4.6, -1.2, 1.8, CHALK, "\u2192 O(n)", "cw-chalk cw-k2"),
    T(13, -3.2, 2.4, CHALK, "= ?", "cw-chalk cw-k3")
  ]);
  var FRONT = [
    G("cw-front cw-f-laptop", [
      R(3.3, 4.2, 9.4, 4, "#2f3136"),
      R(3.8, 4.6, 8.4, 3.2, "#06150b"),
      ...[[4.3, 0], [5.5, 1], [6.7, 2], [7.9, 0], [9.1, 1], [10.3, 2], [11.3, 0]].map(([x, d]) => R(x, 4.8, 0.5, 0.5, "#36d15e", `cw-bit cw-b${d}`)),
      ...[[4.9, 2], [6.1, 0], [8.5, 1], [9.7, 0], [10.9, 2]].map(([x, d]) => R(x, 6.4, 0.5, 0.5, "#36d15e", `cw-bit cw-b${d}`)),
      R(1.8, 8.2, 12.4, 1, "#9aa0a8")
    ]),
    G("cw-front cw-f-vacuum", [R(16, 6.4, 4.2, 3, "#d9534f"), R(16.5, 5.8, 3.2, 0.7, "#b03a37"), C(16.8, 9.6, 0.6, DARK), C(19.4, 9.6, 0.6, DARK)]),
    G("cw-front cw-f-bricks", [
      R(16, 8.6, 2.6, 1.4, "#b5533c"),
      R(18.8, 8.6, 2.6, 1.4, "#a8492f"),
      G("cw-row cw-row1", [R(17.4, 7.1, 2.6, 1.4, "#a8492f"), R(16, 7.1, 1.2, 1.4, "#b5533c")]),
      G("cw-row cw-row2", [R(16.6, 5.6, 2.6, 1.4, "#b5533c")])
    ]),
    G("cw-front cw-f-box", [
      R(5, 3.6, 1.2, 1.2, "#4caf6a", "cw-item cw-i0"),
      R(8.4, 3.4, 1.1, 1.1, "#3d7fd6", "cw-item cw-i1"),
      C(11, 4.2, 0.6, "#f2c94c", "cw-item cw-i2"),
      R(2.5, 5.5, 11, 4.5, "#c79a62"),
      R(7.4, 5.5, 1.2, 4.5, "#a77c48"),
      R(0.8, 4.8, 2.6, 0.9, "#b8894f"),
      R(12.6, 4.8, 2.6, 0.9, "#b8894f")
    ]),
    G("cw-front cw-f-book", [
      R(3.6, 7.4, 8.8, 0.6, "#7a4a2a"),
      R(4, 4.6, 3.8, 3, PAPER),
      R(8.2, 4.6, 3.8, 3, PAPER),
      R(7.8, 4.6, 0.4, 3.2, "#7a4a2a"),
      R(4.5, 5.3, 2.8, 0.3, INK),
      R(4.5, 6.2, 2.4, 0.3, INK),
      R(8.7, 5.3, 2.8, 0.3, INK),
      R(8.7, 6.2, 2.2, 0.3, INK),
      R(8.2, 4.6, 3.8, 3, "#efe9da", "cw-page")
    ]),
    G("cw-front cw-f-knit", [
      ["path", { d: "M8.2 7 C 11 9.8, 14 10.4, 17 9.4", fill: "none", stroke: "#e05a8a", "stroke-width": 0.3 }],
      C(17.5, 9, 1.3, "#e05a8a", "cw-yarn"),
      R(16.9, 8.4, 1.2, 0.3, "#f7c7d8", "cw-yarn"),
      G("cw-scarf", [R(6.8, 7, 2.6, 3, "#e05a8a"), R(6.8, 7.8, 2.6, 0.5, "#f7c7d8"), R(6.8, 9, 2.6, 0.5, "#f7c7d8")]),
      ["line", { x1: 4.4, y1: 5, x2: 9.8, y2: 7.6, stroke: STEEL, "stroke-width": 0.45, class: "cw-needle cw-nl" }],
      ["line", { x1: 11.6, y1: 5, x2: 6.2, y2: 7.6, stroke: STEEL, "stroke-width": 0.45, class: "cw-needle cw-nr" }]
    ]),
    // The lab: an Erlenmeyer flask brewing on a ring stand over a Bunsen burner.
    G("cw-front cw-f-lab", [
      R(16.2, 9.4, 3.6, 0.6, "#5d636b"),
      R(17.6, 7.7, 0.8, 1.7, "#8a9099"),
      ["ellipse", { cx: 18, cy: 6.9, rx: 0.55, ry: 1, fill: "#4aa3ff", class: "cw-flame" }],
      ["ellipse", { cx: 18, cy: 7.15, rx: 0.25, ry: 0.5, fill: "#d6efff", class: "cw-flame" }],
      R(15.9, 5.6, 4.2, 0.35, STEEL),
      R(16, 5.6, 0.3, 4.4, STEEL),
      R(19.7, 5.6, 0.3, 4.4, STEEL),
      ["polygon", { points: "17.3,2 18.7,2 18.7,3.3 20.3,5.6 15.7,5.6 17.3,3.3", fill: "rgba(225,242,255,.7)", stroke: "#b9cbd9", "stroke-width": 0.2 }],
      ["polygon", { points: "16.4,4.6 19.6,4.6 20.3,5.6 15.7,5.6", class: "cw-potion" }],
      C(17.4, 4.9, 0.25, "#ffffffaa", "cw-fizz"),
      C(18.6, 5.1, 0.2, "#ffffffaa", "cw-fizz cw-fz2"),
      C(18, 4.8, 0.2, "#ffffffaa", "cw-fizz cw-fz3"),
      C(18, 1.3, 0.55, "rgba(255,255,255,.7)", "cw-steam"),
      C(18.6, 0.4, 0.45, "rgba(255,255,255,.6)", "cw-steam cw-st2"),
      C(19.6, 1.9, 0.28, "#5ccf6a", "cw-pourdrop")
    ]),
    G("cw-front cw-f-compactor", [
      R(15.5, 2.5, 6, 7.5, "#7d8590"),
      R(16.2, 4.6, 4.6, 4.6, "#2b2f36"),
      G("cw-wad", [R(16.6, 6.8, 3.8, 2.4, PAPER), R(17, 7.4, 3, 0.3, INK), R(17, 8.2, 2.4, 0.3, INK)]),
      G("cw-piston", [R(18.2, 2.5, 0.6, 2.4, "#5d636b"), R(16.2, 4.6, 4.6, 0.8, STEEL)]),
      R(14.6, 5, 0.9, 0.9, "#d9534f")
    ]),
    G("cw-front cw-f-easel", [R(-4.4, -1, 0.6, 11, WOOD), R(-1.2, -1, 0.6, 11, WOOD), R(-4.8, -1.5, 4.6, 5, PAPER), R(-4.2, 0, 3.2, 1.4, PAINT, "cw-canvas")])
  ];
  var FX = [
    G("cw-bubble", [
      C(13.6, -0.6, 0.5, PAPER, null, { stroke: "#c9c5b9", "stroke-width": 0.25 }),
      C(15, -2, 0.8, PAPER, null, { stroke: "#c9c5b9", "stroke-width": 0.25 }),
      ["ellipse", { cx: 16.6, cy: -5, rx: 3.3, ry: 2.2, fill: PAPER, stroke: "#c9c5b9", "stroke-width": 0.25 }],
      C(15.3, -5, 0.45, "#6f6d66", "cw-dot cw-d1"),
      C(16.6, -5, 0.45, "#6f6d66", "cw-dot cw-d2"),
      C(17.9, -5, 0.45, "#6f6d66", "cw-dot cw-d3")
    ]),
    heart(-2.5, -3, 0.5, "cw-heart cw-hh1"),
    heart(15.5, -4, 0.5, "cw-heart cw-hh2"),
    heart(6.5, -6, 0.4, "cw-heart cw-hh3"),
    // a little rain cloud of sadness
    G("cw-cloud", [
      ["ellipse", { cx: 6.4, cy: -4.6, rx: 2.4, ry: 1.5, fill: "#9aa3ad" }],
      ["ellipse", { cx: 9.2, cy: -5.4, rx: 2.8, ry: 2, fill: "#a9b2bc" }],
      ["ellipse", { cx: 11.4, cy: -4.4, rx: 2, ry: 1.3, fill: "#9aa3ad" }],
      R(4.4, -4.4, 9, 1.4, "#a2abb5"),
      R(6, -2.6, 0.4, 1, "#7fb8e6", "cw-rain"),
      R(8.6, -2.4, 0.4, 1, "#7fb8e6", "cw-rain cw-r2"),
      R(11, -2.6, 0.4, 1, "#7fb8e6", "cw-rain cw-r3")
    ]),
    G("cw-tears", [R(5, 4, 0.6, 1, "#8cc4ef", "cw-tear"), R(10, 4, 0.6, 1, "#8cc4ef", "cw-tear cw-t2")]),
    G("cw-sweat", [R(12.6, -0.6, 0.8, 1.2, "#8cc4ef"), R(12.8, -1.2, 0.4, 0.6, "#8cc4ef")]),
    G("cw-notes", [T(-3.5, -1.5, 3, PAINT, "\u266A", "cw-note cw-n1"), T(15.5, -3, 3.4, PAINT, "\u266B", "cw-note cw-n2")]),
    G("cw-glugs", [C(11.4, 1.6, 0.4, "#d6ecfb", "cw-glug"), C(12.6, 0.6, 0.32, "#d6ecfb", "cw-glug cw-g2"), C(13.6, -0.4, 0.28, "#d6ecfb", "cw-glug cw-g3")]),
    G("cw-glints", [T(17.5, 0.5, 2.6, "#f2c94c", "\u2726", "cw-glint"), T(-3.8, 0.5, 2, "#f2c94c", "\u2726", "cw-glint cw-gl2"), T(14, -3.5, 1.8, "#f2c94c", "\u2726", "cw-glint cw-gl3")]),
    G("cw-sparks", [T(17.5, -1.5, 2.6, "#f2c94c", "\u26A1", "cw-spark"), T(-3.5, 2, 2.2, "#f2c94c", "\u26A1", "cw-spark cw-sp2")]),
    G("cw-zap", [C(17, 2.5, 3.2, "rgba(255,255,230,.9)", "cw-flashburst")]),
    G("cw-zzz", [T(13, -0.5, 2.4, "#7a8aa0", "z", "cw-z"), T(15, -2.6, 3, "#7a8aa0", "z", "cw-z cw-z1"), T(17.2, -5, 3.6, "#7a8aa0", "Z", "cw-z cw-z2")])
  ];
  var SPRITE = ["svg", {
    viewBox: `${VIEWBOX.x} ${VIEWBOX.y} ${VIEWBOX.w} ${VIEWBOX.h}`,
    class: "cw-svg m-idle",
    "shape-rendering": "crispEdges",
    "aria-hidden": "true"
  }, [
    G("cw-all", [
      G("cw-backs", [FRONT.find((f) => f[1].class.includes("cw-f-easel")), BOARD, TWIN]),
      G("cw-leg cw-l1", [R(4, 8, 1, 2, BODY)]),
      G("cw-leg cw-l2", [R(6, 8, 1, 2, BODY)]),
      G("cw-leg cw-l3", [R(9, 8, 1, 2, BODY)]),
      G("cw-leg cw-l4", [R(11, 8, 1, 2, BODY)]),
      G("cw-overs", OVERHEAD),
      R(3, 0, 10, 8, BODY, "cw-body"),
      G("cw-look", [G("cw-eyes", [R(5, 2, 1, 2, EYE), R(10, 2, 1, 2, EYE)])]),
      G("cw-mouth", [["ellipse", { cx: 8, cy: 5.6, rx: 1, ry: 0.9, fill: EYE }]]),
      G("cw-hats", HEAD),
      G("cw-arm cw-al", [R(1, 4, 2, 2, BODY), G("cw-lprops", LEFT)]),
      G("cw-arm cw-ar", [R(13, 4, 2, 2, BODY), G("cw-props", RIGHT)]),
      G("cw-fronts", FRONT.filter((f) => !f[1].class.includes("cw-f-easel")))
    ]),
    G("cw-fx", FX)
  ]];
  var SVG_NS = "http://www.w3.org/2000/svg";
  function toDom(doc, node) {
    if (typeof node === "string") return doc.createTextNode(node);
    const [tag, attrs, children] = node;
    const el = doc.createElementNS(SVG_NS, tag);
    for (const [k, v] of Object.entries(attrs)) if (v != null) el.setAttribute(k, v);
    for (const c of children || []) el.appendChild(toDom(doc, c));
    return el;
  }
  var sized = (width, mood) => {
    const [tag, attrs, children] = SPRITE;
    const height = Math.round(width * VIEWBOX.h / VIEWBOX.w);
    return [tag, { ...attrs, class: `cw-svg m-${mood}`, width, height }, children];
  };
  var clawdSpriteNode = (doc, width, mood = "idle") => toDom(doc, sized(width, mood));
  function setMood(svg, mood, extra = "") {
    svg.setAttribute("class", `cw-svg m-${mood}${extra ? ` ${extra}` : ""}`);
  }
  function lookAt(svg, dx, dy) {
    const look = svg.querySelector(".cw-look");
    if (!look) return;
    if (dx == null) {
      look.style.removeProperty("animation");
      look.style.removeProperty("transform");
      return;
    }
    const d = Math.hypot(dx, dy) || 1;
    const x = Math.round(dx / d * 1.2);
    const y = Math.round(dy / d * 1.2);
    look.style.setProperty("animation", "none");
    look.style.setProperty("transform", `translate(${Math.max(-1, Math.min(1, x))}px, ${Math.max(-1, Math.min(1, y))}px)`);
  }
  var eyeOffset = (width) => ({ x: (8 - VIEWBOX.x) * width / VIEWBOX.w, y: (3 - VIEWBOX.y) * width / VIEWBOX.w });
  function tossBottle(doc, parent, x, y, tx, ty, at) {
    const { cursor, onHit, onMiss, scale = 1 } = at || {};
    const win = doc.defaultView;
    const b = doc.createElement("div");
    const st = b.style;
    st.cssText = "position:fixed;left:0;top:0;width:10px;height:22px;border-radius:3px 3px 4px 4px;background:linear-gradient(rgba(255,255,255,.55) 0 70%, rgba(120,190,240,.9) 70%);box-shadow:inset 0 0 0 1px rgba(58,123,213,.5);pointer-events:none;z-index:2147483647;will-change:transform";
    const cap = doc.createElement("div");
    cap.style.cssText = "position:absolute;left:2px;top:-4px;width:6px;height:4px;border-radius:2px 2px 0 0;background:#3a7bd5";
    const label = doc.createElement("div");
    label.style.cssText = "position:absolute;left:0;right:0;top:8px;height:5px;background:#fff";
    b.append(cap, label);
    parent.appendChild(b);
    const g = 1800;
    const flight = Math.max(0.35, Math.min(0.8, Math.hypot(tx - x, ty - y) / 900));
    let vx = (tx - x) / flight;
    let vy = (ty - y) / flight - g * flight / 2;
    if (!Number.isFinite(vx)) {
      vx = -300;
      vy = -600;
    }
    let spin = at ? 0 : (vx >= 0 ? 1 : -1) * 900;
    let px = x;
    let py = y;
    let aligned = !!at;
    let rot = aligned ? Math.atan2(vy, vx) * 180 / Math.PI + 90 : 0;
    let left = at ? flight : 0;
    let last = win.performance.now();
    const frame = (now) => {
      const dt = Math.min(0.05, (now - last) / 1e3);
      last = now;
      if (left > 0 && (left -= dt) <= 0) {
        const m = cursor && cursor();
        if (m && Math.hypot(m.x - px, m.y - py) < 40) {
          aligned = false;
          if (onHit) onHit();
          bonkCursor(doc, parent, m.x, m.y, vx, scale);
          const dir = vx >= 0 ? -1 : 1;
          vx = dir * (160 + Math.random() * 120);
          vy = -Math.abs(vy) * 0.25 - 260;
          spin = dir * (1e3 + Math.random() * 500);
        } else if (onMiss) {
          onMiss();
        }
      }
      vy += g * dt;
      px += vx * dt;
      py += vy * dt;
      if (aligned) rot = Math.atan2(vy, vx) * 180 / Math.PI + 90;
      rot += spin * dt;
      st.transform = `translate(${px - 5}px, ${py - 11}px) rotate(${rot}deg)${scale !== 1 ? ` scale(${scale})` : ""}`;
      const { innerWidth: w, innerHeight: h } = win;
      if (py > h + 60 || px < -80 || px > w + 80) b.remove();
      else win.requestAnimationFrame(frame);
    };
    win.requestAnimationFrame(frame);
  }
  function bonkCursor(doc, parent, x, y, vx, scale = 1) {
    const win = doc.defaultView;
    const box = doc.createElement("div");
    box.style.cssText = `position:fixed;left:0;top:0;pointer-events:none;z-index:2147483647;transform:translate(${x}px, ${y}px)`;
    const ring = doc.createElement("div");
    ring.style.cssText = `position:absolute;left:${-12 * scale}px;top:${-12 * scale}px;width:${24 * scale}px;height:${24 * scale}px;border-radius:50%;border:2px solid rgba(58,123,213,.8);transform:scale(.3);opacity:1;transition:transform .35s ease-out, opacity .35s ease-out`;
    const star = doc.createElement("div");
    star.textContent = "\u2726";
    star.style.cssText = `position:absolute;left:${4 * scale}px;top:${-16 * scale}px;font:${12 * scale}px sans-serif;color:#f2b632;transition:transform .4s ease-out, opacity .4s ease-in;opacity:1`;
    box.append(ring, star);
    parent.appendChild(box);
    win.requestAnimationFrame(() => win.requestAnimationFrame(() => {
      ring.style.transform = "scale(1.6)";
      ring.style.opacity = "0";
      star.style.transform = `translate(${(vx >= 0 ? 1 : -1) * 7 * scale}px, ${-8 * scale}px) rotate(90deg)`;
      star.style.opacity = "0";
    }));
    setTimeout(() => box.remove(), 500);
  }
  var SHOW = {
    read: ["cw-p-paper"],
    search: ["cw-p-glass"],
    fetch: ["cw-o-parcel"],
    paint: ["cw-p-brush", "cw-l-palette", "cw-h-beret"],
    spray: ["cw-p-spray", "cw-h-shades"],
    font: ["cw-p-sign", "cw-l-notepad"],
    write: ["cw-p-pencil", "cw-l-notepad"],
    erase: ["cw-p-eraser"],
    remove: ["cw-p-hose", "cw-f-vacuum"],
    build: ["cw-p-hammer", "cw-h-hardhat"],
    measure: ["cw-p-tape", "cw-h-hardhat"],
    add: ["cw-o-block"],
    wire: ["cw-p-wrench", "cw-sparks"],
    hack: ["cw-f-laptop", "cw-h-shades"],
    watch: ["cw-h-binos"],
    dance: ["cw-h-phones", "cw-notes"],
    photo: ["cw-p-camera", "cw-zap"],
    stash: ["cw-o-chest", "cw-p-key"],
    polish: ["cw-p-sponge", "cw-glints"],
    tinker: ["cw-p-wrench"],
    water: ["cw-p-bottle", "cw-glugs"],
    throw: ["cw-p-bottle"],
    wave: ["cw-p-ask"],
    canvas: ["cw-f-easel", "cw-p-brush", "cw-h-beret"],
    // long-running work, waiting, results
    test: ["cw-l-clipboard", "cw-p-pencil"],
    lab: ["cw-h-goggles", "cw-p-tube", "cw-l-flask", "cw-f-lab"],
    compile: ["cw-h-hardhat", "cw-p-hammer", "cw-f-bricks"],
    install: ["cw-f-box"],
    mail: ["cw-p-plane"],
    ponder: ["cw-b-board", "cw-l-chalk"],
    fork: ["cw-b-twin", "cw-glints"],
    accept: ["cw-o-parcel"],
    wait: ["cw-f-book"],
    knit: ["cw-f-knit"],
    doze: ["cw-zzz", "cw-mouth"],
    cheer: ["cw-glints"],
    facepalm: ["cw-sweat"],
    timer: ["cw-p-timer"],
    compact: ["cw-f-compactor"]
  };
  var showCss = Object.entries(SHOW).map(([mood, groups]) => `${groups.map((g) => `.m-${mood} .${g}`).join(", ")} { display: inline; }`).join("\n");
  var CLAWD_CSS = `
.cw-svg { overflow: visible; display: block; }
.cw-svg * { transform-box: view-box; }
.cw-svg text { shape-rendering: auto; }
.cw-all { transform-origin: 8px 10px; animation: cw-bob 2.6s ease-in-out infinite; }
.cw-look { animation: cw-look 9s steps(1) infinite; }
.cw-eyes { transform-origin: 8px 3px; animation: cw-blink 4.3s infinite; }
.cw-al { transform-origin: 2px 5px; }
.cw-ar { transform-origin: 14px 5px; }
.cw-prop, .cw-lprop, .cw-hat, .cw-over, .cw-front, .cw-bubble, .cw-heart, .cw-sweat,
.cw-notes, .cw-glugs, .cw-glints, .cw-sparks, .cw-zap, .cw-cloud, .cw-tears, .cw-zzz, .cw-mouth { display: none; }
${showCss}

@keyframes cw-bob { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-0.5px); } }
@keyframes cw-blink { 0%, 93%, 100% { transform: scaleY(1); } 96% { transform: scaleY(0.15); } }
@keyframes cw-look { 0% { transform: none; } 45% { transform: translateX(-1px); } 60% { transform: translateX(1px); } 75% { transform: none; } }
@keyframes cw-step { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-1px); } }
@keyframes cw-hop { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-1px); } }
@keyframes cw-dots { 0%, 100% { opacity: .25; } 40% { opacity: 1; } }
@keyframes cw-float { 0% { opacity: 0; transform: translateY(1px); } 25% { opacity: 1; } 100% { opacity: 0; transform: translateY(-5px); } }
@keyframes cw-blinkfx { 0%, 100% { opacity: 0; } 50% { opacity: 1; } }
@keyframes cw-scan { 0%, 100% { transform: translate(0, .5px); } 50% { transform: translate(1px, .5px); } }
@keyframes cw-shake { 0%, 100% { transform: translateX(0); } 50% { transform: translateX(.3px); } }

/* walking: legs alternate in whole pixels */
.m-walk .cw-all, .m-fetch .cw-all { animation: cw-hop .32s steps(2) infinite; }
.m-walk .cw-l1, .m-walk .cw-l3, .m-fetch .cw-l1, .m-fetch .cw-l3 { animation: cw-step .32s steps(2) infinite; }
.m-walk .cw-l2, .m-walk .cw-l4, .m-fetch .cw-l2, .m-fetch .cw-l4 { animation: cw-step .32s steps(2) -.16s infinite; }
.m-walk .cw-look { animation: none; transform: translateX(1px); }

/* thinking: eyes up, bubble with dots */
.m-think .cw-bubble { display: inline; }
.m-think .cw-look { animation: none; transform: translate(1px, -1px); }
.cw-dot { animation: cw-dots 1.2s infinite; }
.cw-d2 { animation-delay: .2s; } .cw-d3 { animation-delay: .4s; }

/* reading: holds a sheet, eyes scan it */
.m-read .cw-ar { transform: translateY(-1px); }
.m-read .cw-look { animation: cw-scan 1.4s steps(2) infinite; }

/* searching: sweeps the magnifying glass */
@keyframes cw-sweep { 0%, 100% { transform: rotate(-25deg); } 50% { transform: rotate(20deg); } }
.m-search .cw-ar { animation: cw-sweep 1.3s ease-in-out infinite; }
.m-search .cw-look { animation: cw-scan 1.3s steps(2) infinite; }

/* oil painting: palette in one hand, brush strokes with the other, beret on */
@keyframes cw-stroke { 0% { transform: rotate(-35deg); } 100% { transform: rotate(15deg); } }
.m-paint .cw-ar, .m-canvas .cw-ar { animation: cw-stroke .45s ease-in-out infinite alternate; }
.m-paint .cw-look { animation: none; transform: translateX(1px); }
.m-paint .cw-al { transform: translateY(-1px); }
.m-canvas .cw-look { animation: none; transform: translateX(-1px); }

/* spray paint: shades on, can shakes, mist puffs */
@keyframes cw-rattle { 0%, 100% { transform: rotate(-12deg) translateY(0); } 50% { transform: rotate(8deg) translateY(-.5px); } }
.m-spray .cw-ar { animation: cw-rattle .2s steps(2) infinite; }
.cw-mist { animation: cw-blinkfx .5s steps(2) infinite; }
.cw-m2 { animation-delay: .17s; } .cw-m3 { animation-delay: .33s; }

/* typography: holds up an "Aa" sign that pulses bigger */
@keyframes cw-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.15); } }
.m-font .cw-p-sign { transform-origin: 16.7px 0; animation: cw-pulse 1s ease-in-out infinite; }
.m-font .cw-ar { transform: rotate(-10deg); }

/* writing: pencil taps on the notepad, eyes down */
@keyframes cw-tap { 0% { transform: translateY(0) rotate(10deg); } 100% { transform: translateY(1px) rotate(25deg); } }
.m-write .cw-ar { animation: cw-tap .14s steps(2) infinite alternate; }
.m-write .cw-look, .m-font .cw-look { animation: none; transform: translate(-1px, 1px); }

/* erasing: rubs back and forth */
@keyframes cw-rub { 0% { transform: translate(-1px, 0); } 100% { transform: translate(1px, .5px); } }
.m-erase .cw-ar { animation: cw-rub .16s steps(2) infinite alternate; }
.m-erase .cw-all { animation: cw-shake .16s infinite; }

/* removing: vacuum cleaner rumbles */
.m-remove .cw-all { animation: cw-shake .1s infinite; }
@keyframes cw-suck { 0%, 100% { transform: rotate(-20deg); } 50% { transform: rotate(-35deg); } }
.m-remove .cw-ar { animation: cw-suck .4s ease-in-out infinite; }
.m-remove .cw-f-vacuum { animation: cw-shake .08s infinite; }

/* building: hard hat, hammer bonks with a squash on impact */
@keyframes cw-bonk { 0%, 55% { transform: rotate(-80deg); } 75% { transform: rotate(20deg); } 100% { transform: rotate(-80deg); } }
@keyframes cw-squash { 0%, 70%, 100% { transform: scale(1, 1); } 78% { transform: scale(1.06, .92); } }
.m-build .cw-ar { animation: cw-bonk .7s ease-in infinite; }
.m-build .cw-all { animation: cw-squash .7s infinite; }

/* measuring: tape extends and snaps back */
@keyframes cw-tape { 0%, 100% { transform: scaleX(.2); } 60% { transform: scaleX(1.6); } }
.m-measure .cw-tape { transform-origin: 18px 4.7px; animation: cw-tape 1.6s ease-in-out infinite; }
.m-measure .cw-look { animation: none; transform: translateX(1px); }

/* adding: carries a new block overhead */
.m-add .cw-arm, .m-fetch .cw-arm, .m-stash .cw-al { transform: translateY(-3px); }
.m-add .cw-all { animation: cw-hop .5s steps(2) infinite; }
.m-stash .cw-ar { transform: rotate(-30deg); }
@keyframes cw-turn { 0%, 100% { transform: rotate(0); } 50% { transform: rotate(-60deg); } }
.m-stash .cw-p-key { transform-origin: 16px 3px; animation: cw-turn .8s steps(2) infinite; }

/* wiring behaviour: wrench twists, sparks fly */
@keyframes cw-twist { 0% { transform: rotate(-30deg); } 100% { transform: rotate(25deg); } }
.m-wire .cw-ar { animation: cw-twist .22s steps(2) infinite alternate; }
.m-tinker .cw-ar { animation: cw-twist .6s ease-in-out infinite alternate; }
.cw-spark { animation: cw-blinkfx .3s steps(2) infinite; }
.cw-sp2 { animation-delay: .15s; }

/* hacking: shades, laptop, both hands typing, matrix bits flicker */
@keyframes cw-type { 0% { transform: translateY(1px); } 100% { transform: translateY(2px); } }
.m-hack .cw-al { animation: cw-type .12s steps(2) infinite alternate; }
.m-hack .cw-ar { animation: cw-type .12s steps(2) -.06s infinite alternate; }
.m-hack .cw-all { animation: none; }
.cw-bit { animation: cw-blinkfx .6s steps(2) infinite; }
.cw-b1 { animation-delay: .2s; } .cw-b2 { animation-delay: .4s; }

/* keeping watch: binoculars sweep */
.m-watch .cw-hats { animation: cw-scan 2s steps(4) infinite; }
.m-watch .cw-arm { transform: translateY(-2px); }

/* animations/transitions: headphones on, dancing */
@keyframes cw-dance { 0%, 100% { transform: rotate(-6deg) translateY(0); } 50% { transform: rotate(6deg) translateY(-1px); } }
.m-dance .cw-all { animation: cw-dance .5s ease-in-out infinite; }
.m-dance .cw-al { animation: cw-wave .5s steps(2) infinite; }
.m-dance .cw-ar { animation: cw-wave .5s steps(2) -.25s infinite; }
.cw-note { animation: cw-float 1.4s ease-out infinite; }
.cw-n2 { animation-delay: .7s; }

/* photos: camera flash */
@keyframes cw-burst { 0%, 80%, 100% { opacity: 0; } 85% { opacity: 1; } }
.cw-flashburst { animation: cw-burst 1.6s infinite; }
.m-photo .cw-ar { transform: translateY(-1px); }
.m-photo .cw-eyes { animation: cw-wink 1.6s infinite; }
@keyframes cw-wink { 0%, 80%, 100% { transform: scaleY(1); } 85% { transform: scaleY(.15); } }

/* polishing: sponge circles, glints */
@keyframes cw-circle { 0% { transform: translate(0, 0); } 25% { transform: translate(1px, -.5px); } 50% { transform: translate(0, -1px); } 75% { transform: translate(-1px, -.5px); } 100% { transform: translate(0, 0); } }
.m-polish .cw-ar { animation: cw-circle .5s linear infinite; }
.cw-glint { animation: cw-blinkfx 1s steps(2) infinite; }
.cw-gl2 { animation-delay: .33s; } .cw-gl3 { animation-delay: .66s; }

/* water break (3s, once): hand to the face, cap at the mouth, tip it back as it empties.
   The arm moves the hand in front of the face; the bottle pivots on its cap, which
   lands at (9.6, 4.6) \u2014 where Clawd's mouth would be, just under his eyes. */
@keyframes cw-sip { 0%, 100% { transform: none; } 14%, 86% { transform: translate(-3px, -.5px); } }
@keyframes cw-tip {
  0%, 100% { transform: none; }
  14% { transform: translate(-3.5px, 8.6px) rotate(-100deg); }
  50% { transform: translate(-3.5px, 8.6px) rotate(-122deg); }
  86% { transform: translate(-3.5px, 8.6px) rotate(-138deg); }
}
.m-water .cw-ar { animation: cw-sip 3s ease-in-out forwards; }
.m-water .cw-p-bottle { transform-origin: 16.1px -3.5px; animation: cw-tip 3s ease-in-out forwards; }
.m-water .cw-eyes { animation: none; transform: scaleY(.15); }
.m-water .cw-all { animation: cw-bob 1.2s ease-in-out infinite; }
@keyframes cw-drain { 0%, 14% { transform: scaleY(1); } 86%, 100% { transform: scaleY(3.6); } }
.m-water .cw-water-air { transform-origin: 16px -3px; animation: cw-drain 3s ease-in forwards; }
.cw-glug { animation: cw-float .9s ease-out infinite; animation-delay: .5s; }
.cw-g2 { animation-delay: .8s; } .cw-g3 { animation-delay: 1.1s; }

/* tossing the empty bottle: wind up and fling (the flying bottle is drawn separately) */
@keyframes cw-throw { 0% { transform: rotate(35deg); } 60% { transform: rotate(35deg); } 100% { transform: rotate(-150deg); } }
.m-throw .cw-ar { animation: cw-throw .45s cubic-bezier(.5, 0, .9, .4) forwards; }
.m-throw .cw-water-air { transform-origin: 16px -3px; transform: scaleY(3.6); }
.m-throw .cw-look { animation: none; transform: translate(1px, -1px); }

/* the page broke: rain cloud, tears, droopy everything */
@keyframes cw-rainfall { 0% { opacity: 0; transform: translateY(0); } 20% { opacity: 1; } 100% { opacity: 0; transform: translateY(4px); } }
@keyframes cw-cry { 0% { opacity: 0; transform: translateY(0); } 25% { opacity: 1; } 100% { opacity: 0; transform: translateY(3.5px); } }
@keyframes cw-mope { 0%, 100% { transform: translateY(.8px) rotate(-2deg); } 50% { transform: translateY(1px) rotate(2deg); } }
.m-sad .cw-cloud, .m-sad .cw-tears { display: inline; }
.m-sad .cw-all { animation: cw-mope 2.4s ease-in-out infinite; }
.m-sad .cw-arm { transform: translateY(1.5px); }
.m-sad .cw-look { animation: none; transform: translateY(1px); }
.m-sad .cw-eyes { animation: none; transform: scaleY(.45); }
.cw-rain { animation: cw-rainfall .7s linear infinite; }
.cw-r2 { animation-delay: .25s; } .cw-r3 { animation-delay: .5s; }
.cw-tear { animation: cw-cry 1.1s ease-in infinite; }
.cw-t2 { animation-delay: .55s; }

/* running the tests: ticks off a checklist */
@keyframes cw-chk0 { 0%, 8% { opacity: 0; } 9%, 94% { opacity: 1; } 95%, 100% { opacity: 0; } }
@keyframes cw-chk1 { 0%, 38% { opacity: 0; } 39%, 94% { opacity: 1; } 95%, 100% { opacity: 0; } }
@keyframes cw-chk2 { 0%, 68% { opacity: 0; } 69%, 94% { opacity: 1; } 95%, 100% { opacity: 0; } }
.m-test .cw-c0 { animation: cw-chk0 2.6s steps(1) infinite; }
.m-test .cw-c1 { animation: cw-chk1 2.6s steps(1) infinite; }
.m-test .cw-c2 { animation: cw-chk2 2.6s steps(1) infinite; }
.m-test .cw-al { transform: translateY(-1px); }
.m-test .cw-ar { animation: cw-tap .26s steps(2) infinite alternate; }
.m-test .cw-look { animation: none; transform: translate(-1px, 1px); }

/* ...or, half the time, brewing in the lab: goggles on, tipping a test tube into a flask
   that bubbles, steams and changes colour over a Bunsen burner */
@keyframes cw-pour { 0%, 100% { transform: rotate(36deg); } 50% { transform: rotate(44deg); } }
@keyframes cw-bubble { 0% { opacity: 0; transform: translateY(1px); } 30% { opacity: 1; } 100% { opacity: 0; transform: translateY(-2.5px); } }
@keyframes cw-brew { 0%, 100% { fill: #5ccf6a; } 33% { fill: #4aa3ff; } 66% { fill: #b46be0; } }
@keyframes cw-flicker { 0%, 100% { transform: scale(1, 1); } 50% { transform: scale(.85, 1.2); } }
@keyframes cw-fall { 0% { opacity: 0; transform: none; } 15% { opacity: 1; } 80% { opacity: 1; transform: translateY(2.8px); } 100% { opacity: 0; transform: translateY(3px); } }
.m-lab .cw-ar { animation: cw-pour 1.2s ease-in-out infinite; }
.cw-potion { fill: #5ccf6a; }
.m-lab .cw-potion { animation: cw-brew 4.5s linear infinite; }
.m-lab .cw-flame { transform-origin: 18px 7.9px; animation: cw-flicker .25s steps(2) infinite; }
.m-lab .cw-fizz { animation: cw-bubble .8s ease-out infinite; }
.m-lab .cw-fz2 { animation-delay: .27s; } .m-lab .cw-fz3 { animation-delay: .53s; }
.m-lab .cw-steam { animation: cw-float 1.6s ease-out infinite; }
.m-lab .cw-st2 { animation-delay: .8s; }
.m-lab .cw-pourdrop { animation: cw-fall .6s ease-in infinite; }
.m-lab .cw-al { transform: translateY(-1px); }
.m-lab .cw-bub { animation: cw-bubble 1s ease-out infinite; }
.m-lab .cw-bub2 { animation-delay: .33s; } .m-lab .cw-bub3 { animation-delay: .66s; }
.m-lab .cw-look { animation: none; transform: translate(1px, -1px); }

/* building the project: hard hat, hammers away while the wall grows */
@keyframes cw-row1 { 0%, 32% { opacity: 0; } 33%, 100% { opacity: 1; } }
@keyframes cw-row2 { 0%, 65% { opacity: 0; } 66%, 100% { opacity: 1; } }
.m-compile .cw-ar { animation: cw-bonk .7s ease-in infinite; }
.m-compile .cw-all { animation: cw-squash .7s infinite; }
.m-compile .cw-row1 { animation: cw-row1 2.7s steps(1) infinite; }
.m-compile .cw-row2 { animation: cw-row2 2.7s steps(1) infinite; }
.m-compile .cw-look { animation: none; transform: translateX(1px); }

/* installing packages: digs through a parcel, things pop out */
@keyframes cw-dig { 0% { transform: translateY(1px); } 100% { transform: translateY(-1.5px); } }
@keyframes cw-popout { 0% { opacity: 0; transform: translateY(2px); } 30% { opacity: 1; } 100% { opacity: 0; transform: translateY(-5px); } }
.m-install .cw-al { animation: cw-dig .3s steps(2) infinite alternate; }
.m-install .cw-ar { animation: cw-dig .3s steps(2) -.15s infinite alternate; }
.m-install .cw-item { animation: cw-popout 1.5s ease-out infinite; }
.m-install .cw-i1 { animation-delay: .5s; } .m-install .cw-i2 { animation-delay: 1s; }
.m-install .cw-look { animation: none; transform: translateY(1px); }

/* git push/pull: folds and flings paper planes */
@keyframes cw-fling { 0%, 50% { transform: rotate(30deg); } 62% { transform: rotate(-70deg); } 100% { transform: rotate(30deg); } }
@keyframes cw-fly { 0%, 58% { opacity: 1; transform: none; } 100% { opacity: 0; transform: translate(9px, -9px); } }
.m-mail .cw-ar { animation: cw-fling 1.8s ease-in infinite; }
.m-mail .cw-plane { animation: cw-fly 1.8s ease-in infinite; }
.m-mail .cw-look { animation: none; transform: translate(1px, -1px); }

/* thinking hard: paces in front of a chalkboard, hand on chin */
@keyframes cw-pace { 0%, 100% { transform: translateX(-2px); } 50% { transform: translateX(2px); } }
@keyframes cw-chalk { 0% { opacity: 0; } 8%, 92% { opacity: 1; } 100% { opacity: 0; } }
.m-ponder .cw-all { animation: cw-pace 4s ease-in-out infinite; }
/* ...while the board (inside the same group) stands still: the exact opposite motion */
@keyframes cw-unpace { 0%, 100% { transform: translateX(2px); } 50% { transform: translateX(-2px); } }
.m-ponder .cw-b-board { animation: cw-unpace 4s ease-in-out infinite; }
.m-ponder .cw-l1, .m-ponder .cw-l3 { animation: cw-step .5s steps(2) infinite; }
.m-ponder .cw-l2, .m-ponder .cw-l4 { animation: cw-step .5s steps(2) -.25s infinite; }
.m-ponder .cw-ar { transform: translate(-4px, 0); }
/* a hand in front of his own body: a shade darker, or it disappears */
.m-ponder .cw-ar > rect, .m-facepalm .cw-ar > rect { filter: brightness(.8); }
.m-ponder .cw-look { animation: none; transform: translate(1px, -1px); }
.m-ponder .cw-chalk { opacity: 0; animation: cw-chalk 8s steps(1) infinite; }
.m-ponder .cw-k1 { animation-delay: 1.6s; } .m-ponder .cw-k2 { animation-delay: 3.2s; } .m-ponder .cw-k3 { animation-delay: 4.8s; }

/* ...writing on it with a stick of chalk */
@keyframes cw-scribble { 0% { transform: translate(-.4px, -2.6px); } 50% { transform: translate(.4px, -2.2px); } 100% { transform: translate(-.2px, -2.4px); } }
.m-ponder .cw-al { animation: cw-scribble .35s steps(3) infinite; }

/* forking a helper: strains, and a copy of him slides out and shrinks to baby size */
@keyframes cw-strain { 0%, 100% { transform: scale(1, 1); } 30% { transform: scale(1.08, .9); } 45% { transform: scale(.94, 1.06); } 60% { transform: scale(1, 1); } }
@keyframes cw-split { 0%, 22% { opacity: 0; transform: none; } 30% { opacity: 1; transform: translateX(-2px); }
  70% { opacity: 1; transform: translateX(-10px) scale(.48); } 74%, 100% { opacity: 0; transform: translateX(-10px) scale(.48); } }
.m-fork .cw-all { animation: cw-strain 1.5s ease-in-out 1; }
.m-fork .cw-b-twin { transform-origin: 8px 10px; animation: cw-split 1.5s ease-in-out forwards; }
.m-fork .cw-eyes { animation: none; transform: scaleY(.3); }
.m-fork .cw-arm { transform: translateY(-1px); }

/* a helper's coming back: arms out for its parcel */
@keyframes cw-reach { 0%, 100% { transform: translate(0, -1.5px); } 50% { transform: translate(0, -2.5px); } }
.m-expect .cw-al { animation: cw-reach .6s ease-in-out infinite; }
.m-expect .cw-ar { animation: cw-reach .6s ease-in-out -.3s infinite; }
.m-expect .cw-look { animation: none; transform: translateX(-1px); }
/* ...and takes it: parcel overhead, a happy hop, hearts */
.m-accept .cw-arm { transform: translateY(-3px); }
.m-accept .cw-all { animation: cw-jump .75s ease-in-out infinite; }
.m-accept .cw-eyes { animation: none; transform: scaleY(.5); }
.m-accept .cw-heart { display: inline; animation: cw-float 1.4s ease-out infinite; }
.m-accept .cw-hh2 { animation-delay: .45s; } .m-accept .cw-hh3 { animation-delay: .9s; }

/* a long wait: sits down with a book, or some knitting */
.cw-leg { transform-origin: 0 10px; }
.m-wait .cw-all, .m-knit .cw-all { animation: none; transform: translateY(1px); }
.m-wait .cw-leg, .m-knit .cw-leg, .m-doze .cw-leg { transform: scaleY(.5); }
.m-wait .cw-arm { transform: translateY(1px); }
.m-wait .cw-look { animation: cw-scan 2.4s steps(2) infinite; }
@keyframes cw-pageflip { 0%, 84% { transform: scaleX(1); } 92% { transform: scaleX(0); } 100% { transform: scaleX(-1); } }
.m-wait .cw-page { transform-origin: 8px 6px; animation: cw-pageflip 5s ease-in-out infinite; }
@keyframes cw-knitl { 0% { transform: rotate(-7deg); } 100% { transform: rotate(5deg); } }
@keyframes cw-grow { 0% { transform: scaleY(.3); } 100% { transform: scaleY(1.3); } }
@keyframes cw-roll { 0%, 100% { transform: translateX(0); } 50% { transform: translateX(.4px); } }
.m-knit .cw-arm { transform: translateY(.5px); }
.m-knit .cw-nl { transform-origin: 8px 6.3px; animation: cw-knitl .19s steps(2) infinite alternate; }
.m-knit .cw-nr { transform-origin: 8px 6.3px; animation: cw-knitl .19s steps(2) -.1s infinite alternate-reverse; }
.m-knit .cw-scarf { transform-origin: 8px 7px; animation: cw-grow 30s linear infinite; }
.m-knit .cw-yarn { animation: cw-roll .8s steps(2) infinite; }
.m-knit .cw-look { animation: none; transform: translateY(1px); }

/* a very long wait: yawns, nods off */
@keyframes cw-breathe { 0%, 100% { transform: translateY(1px) scale(1, 1); } 50% { transform: translateY(1px) scale(1.03, .97); } }
@keyframes cw-yawnmouth { 0% { transform: scale(0); } 25%, 45% { transform: scale(1, 1.3); } 60%, 100% { transform: scale(0); } }
@keyframes cw-zfloat { 0% { opacity: 0; transform: translate(0, 1px); } 20% { opacity: 1; } 100% { opacity: 0; transform: translate(1.5px, -3px); } }
.m-doze .cw-all { animation: cw-breathe 3.2s ease-in-out infinite; }
.m-doze .cw-eyes { animation: none; transform: scaleY(.15); }
.m-doze .cw-look { animation: none; transform: translateY(1px); }
.m-doze .cw-arm { transform: translateY(1.5px); }
.m-doze .cw-mouth { transform-origin: 8px 5.6px; animation: cw-yawnmouth 3s ease-in-out forwards; }
.m-doze .cw-z { animation: cw-zfloat 3s ease-out infinite; animation-delay: 2.4s; opacity: 0; }
.m-doze .cw-z1 { animation-delay: 3.4s; } .m-doze .cw-z2 { animation-delay: 4.4s; }

/* it worked: fist pump */
@keyframes cw-pump { 0% { transform: translateY(-2px) rotate(0); } 100% { transform: translateY(-4.5px) rotate(-12deg); } }
.m-cheer .cw-all { animation: cw-jump .7s ease-in-out infinite; }
.m-cheer .cw-ar { animation: cw-pump .18s steps(2) infinite alternate; }
.m-cheer .cw-eyes { animation: none; transform: scaleY(.5); }

/* it didn't: facepalm */
@keyframes cw-tsk { 0%, 100% { transform: translateY(.6px) rotate(0); } 25% { transform: translateY(.6px) rotate(-3deg); } 75% { transform: translateY(.6px) rotate(3deg); } }
.m-facepalm .cw-all { animation: cw-tsk .7s ease-in-out 2; }
.m-facepalm .cw-ar { transform: translate(-4px, -2.5px); }
.m-facepalm .cw-al { transform: translateY(1px); }
.m-facepalm .cw-eyes { animation: none; transform: scaleY(.3); }
.m-facepalm .cw-sweat { display: inline; animation: cw-drip 1.6s ease-in infinite; }

/* background task: winds a kitchen timer */
@keyframes cw-dialturn { 0% { transform: rotate(0); } 100% { transform: rotate(360deg); } }
.m-timer .cw-dial { transform-origin: 16.2px 2.6px; animation: cw-dialturn 1.2s steps(12) infinite; }
.m-timer .cw-ar { transform: translateY(-1.5px); }
.m-timer .cw-look { animation: none; transform: translateX(1px); }

/* compacting the conversation: the trash compactor squashes it */
@keyframes cw-press { 0%, 15%, 100% { transform: translateY(0); } 50%, 65% { transform: translateY(2.4px); } }
@keyframes cw-squish { 0%, 15%, 100% { transform: scaleY(1); } 50%, 65% { transform: scaleY(.35); } }
.m-compact .cw-piston { animation: cw-press 1.3s ease-in-out infinite; }
.m-compact .cw-wad { transform-origin: 18px 9.2px; animation: cw-squish 1.3s ease-in-out infinite; }
.m-compact .cw-ar { animation: cw-type .65s steps(2) infinite alternate; }
.m-compact .cw-eyes { animation: none; transform: scaleY(.5); }

/* tickled: giggles and wiggles */
@keyframes cw-giggle { 0%, 100% { transform: rotate(-7deg); } 50% { transform: rotate(7deg) translateY(-.5px); } }
.cw-tickle .cw-all { animation: cw-giggle .14s infinite !important; }
.cw-tickle .cw-eyes { animation: none !important; transform: scaleY(.3) !important; }
.cw-tickle .cw-arm { animation: cw-wave .2s steps(2) infinite !important; }
.cw-tickle .cw-heart { display: inline; animation: cw-float 1s ease-out infinite; }
.cw-tickle .cw-hh2 { animation-delay: .3s; } .cw-tickle .cw-hh3 { animation-delay: .6s; }

/* noticed the cursor: a little start */
@keyframes cw-start { 0%, 100% { transform: translateY(0); } 40% { transform: translateY(-2px) scale(1.04, .97); } }
.cw-notice .cw-all { animation: cw-start .35s ease-out 1; }

/* needs the user: waves a sign, taps a foot */
@keyframes cw-waggle { 0%, 100% { transform: rotate(-8deg); } 50% { transform: rotate(8deg); } }
.m-wave .cw-ar { animation: cw-waggle .6s ease-in-out infinite; }
.m-wave .cw-al { animation: cw-wave .6s steps(2) infinite; }
.m-wave .cw-l4 { animation: cw-step .4s steps(2) infinite; }
.m-wave .cw-look { animation: none; transform: translateY(-.5px); }

/* done: happy jumps, arms up, hearts */
@keyframes cw-jump {
  0%, 100% { transform: translateY(0) scale(1, 1); }
  12% { transform: translateY(0) scale(1.08, .9); }
  40% { transform: translateY(-3px) scale(.95, 1.06); }
  70% { transform: translateY(0) scale(1, 1); }
  80% { transform: translateY(0) scale(1.06, .93); }
}
@keyframes cw-wave { 0%, 100% { transform: translateY(-3px) rotate(0); } 50% { transform: translateY(-3px) rotate(-20deg); } }
.m-done .cw-all { animation: cw-jump .9s ease-in-out infinite; }
.m-done .cw-arm { animation: cw-wave .45s steps(2) infinite; }
.m-done .cw-eyes { animation: none; transform: scaleY(.5); }
.m-done .cw-heart { display: inline; animation: cw-float 1.8s ease-out infinite; }
.m-done .cw-hh2 { animation-delay: .6s; } .m-done .cw-hh3 { animation-delay: 1.2s; }

/* error: droops, sweats */
.m-error .cw-all { animation: none; transform: translateY(.6px); }
.m-error .cw-arm { transform: translateY(1px); }
.m-error .cw-look { animation: none; transform: translateY(1px); }
.m-error .cw-eyes { animation: none; transform: scaleY(.5); }
@keyframes cw-drip { 0% { opacity: 0; transform: translateY(0); } 20% { opacity: 1; } 100% { opacity: 0; transform: translateY(3px); } }
.m-error .cw-sweat { display: inline; animation: cw-drip 1.6s ease-in infinite; }

/* a click on Clawd */
.cw-poke .cw-all { animation: cw-jump .6s ease-in-out 1; }
.cw-poke .cw-hh1 { display: inline; animation: cw-float 1s ease-out 1; }

@media (prefers-reduced-motion: reduce) {
  .cw-svg * { animation-duration: 0s !important; animation-iteration-count: 1 !important; }
}
`;

  // src/clawd-actions.js
  var EMOJI = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{2300}-\u{23FF}\u{E0020}-\u{E007F}]|\u{FE0F}|\u{200D}|\u{20E3}/gu;
  function plainSay(text) {
    return String(text || "").replace(/\s*[\u2014\u2013]\s*/g, ", ").replace(EMOJI, "").replace(/\s{2,}/g, " ").replace(/\s+([,.!?…])/g, "$1").trim();
  }
  var DODGED = ["Aw, you dodged it\u2026", "Hey, you moved! Not fair\u2026", "Missed\u2026 you\u2019re too quick", "I was aiming for you\u2026"];
  var TASK_RESULT = {
    test: ["Tests passed!", "Tests failed"],
    lint: ["All tidy!", "Lint found problems"],
    build: ["Build succeeded!", "Build failed"],
    install: ["Installed!", "Install failed"],
    sync: ["Synced!", "Sync failed"]
  };
  var MOOD_LABEL = {
    idle: "Ready when you are",
    think: "Thinking\u2026",
    done: "All done!",
    error: "Oops, that didn\u2019t work",
    wave: "Need you in the terminal",
    water: "Hydrating\u2026 AI is thirsty work",
    ponder: "Thinking it through",
    compact: "Compacting my memory",
    background: "Left it running in the background"
  };

  // src/clawd-sound.js
  var ctx = null;
  var master = null;
  var noiseBuf = null;
  function tone(f, dur, { type = "square", vol = 0.3, to = null, at = 0, vibrato = 0 } = {}) {
    const t = ctx.currentTime + at;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t + dur);
    if (vibrato) {
      const lfo = ctx.createOscillator();
      const lg = ctx.createGain();
      lfo.frequency.value = 6;
      lg.gain.value = vibrato;
      lfo.connect(lg).connect(o.frequency);
      lfo.start(t);
      lfo.stop(t + dur);
    }
    g.gain.setValueAtTime(1e-4, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 8e-3);
    g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
    o.connect(g).connect(master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
  function noise(dur, { vol = 0.25, freq = 1500, to = null, kind = "bandpass", q = 1, at = 0 } = {}) {
    const t = ctx.currentTime + at;
    const s = ctx.createBufferSource();
    s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = kind;
    f.Q.value = q;
    f.frequency.setValueAtTime(freq, t);
    if (to) f.frequency.exponentialRampToValueAtTime(to, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(1e-4, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
    s.connect(f).connect(g).connect(master);
    s.start(t, Math.random() * 0.5);
    s.stop(t + dur + 0.02);
  }
  var rnd = (a, b) => a + Math.random() * (b - a);
  var PENTA = [523, 587, 659, 784, 880, 1047];
  var note = 0;
  var SOUNDS = {
    step: () => tone(rnd(170, 230), 0.045, { type: "triangle", vol: 0.22 }),
    glug: () => tone(rnd(300, 360), 0.11, { type: "sine", vol: 0.35, to: 160 }),
    ahh: () => {
      tone(560, 0.35, { type: "sine", vol: 0.18, to: 420, vibrato: 12 });
      noise(0.3, { vol: 0.05, freq: 900 });
    },
    whoosh: () => noise(0.3, { vol: 0.25, freq: 400, to: 2600, q: 2 }),
    giggle: () => [0, 1, 2, 3, 4, 5].forEach((i) => tone(i % 2 ? 760 : 980, 0.05, { type: "square", vol: 0.12, at: i * 0.07, to: i % 2 ? 820 : 1040 })),
    pop: () => tone(520, 0.07, { type: "sine", vol: 0.35, to: 1300 }),
    boop: () => tone(480, 0.08, { type: "sine", vol: 0.25, to: 720 }),
    swish: () => noise(0.18, { vol: 0.16, freq: 2500, to: 5e3, kind: "highpass" }),
    psst: () => noise(0.22, { vol: 0.14, freq: 3500, kind: "highpass" }),
    vacuum: () => {
      noise(1.05, { vol: 0.12, freq: 500, to: 700, kind: "lowpass" });
      tone(110, 1.05, { type: "sawtooth", vol: 0.04, vibrato: 4 });
    },
    slurp: () => tone(900, 0.35, { type: "sine", vol: 0.25, to: 140 }),
    bonk: () => {
      tone(170, 0.13, { type: "sine", vol: 0.45, to: 80 });
      noise(0.03, { vol: 0.2, freq: 3200, kind: "highpass" });
    },
    squeak: () => tone(rnd(1300, 1500), 0.07, { type: "square", vol: 0.08, to: 1900 }),
    tick: () => noise(0.025, { vol: 0.18, freq: 4500, kind: "highpass" }),
    chime: () => [880, 1320, 1760].forEach((f, i) => tone(f, 0.25, { type: "sine", vol: 0.15, at: i * 0.06 })),
    zap: () => tone(1300, 0.13, { type: "sawtooth", vol: 0.1, to: 180 }),
    blip: () => tone(rnd(600, 1300), 0.035, { type: "square", vol: 0.08 }),
    note: () => tone(PENTA[note = (note + 1 + Math.floor(Math.random() * 2)) % PENTA.length], 0.14, { type: "triangle", vol: 0.22 }),
    shutter: () => {
      noise(0.035, { vol: 0.3, freq: 3e3 });
      noise(0.05, { vol: 0.25, freq: 2e3, at: 0.08 });
    },
    shimmer: () => [1568, 2093, 2637].forEach((f, i) => tone(f, 0.18, { type: "sine", vol: 0.06, at: i * 0.05 })),
    zip: () => tone(300, 0.28, { type: "square", vol: 0.06, to: 1e3 }),
    creak: () => {
      tone(140, 0.3, { type: "sawtooth", vol: 0.05, to: 210 });
      tone(988, 0.08, { type: "square", vol: 0.1, at: 0.32 });
      tone(1319, 0.25, { type: "square", vol: 0.1, at: 0.4 });
    },
    sonar: () => tone(1050, 0.5, { type: "sine", vol: 0.18 }),
    hmm: () => tone(260, 0.3, { type: "triangle", vol: 0.18, to: 235 }),
    boing: () => {
      tone(180, 0.12, { type: "sine", vol: 0.3, to: 520 });
      tone(520, 0.15, { type: "sine", vol: 0.2, to: 300, at: 0.12 });
    },
    thought: () => tone(900, 0.04, { type: "sine", vol: 0.12 }),
    flip: () => noise(0.08, { vol: 0.18, freq: 1500, to: 900 }),
    dingdong: () => {
      tone(659, 0.4, { type: "sine", vol: 0.3 });
      tone(523, 0.55, { type: "sine", vol: 0.3, at: 0.35 });
    },
    happy: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.1, { type: "square", vol: 0.12, at: i * 0.08 })),
    sad: () => [[392, 370], [370, 349], [349, 330], [330, 294]].forEach(([f, to], i) => tone(f, i === 3 ? 0.9 : 0.32, { type: "triangle", vol: 0.25, to, at: i * 0.36, vibrato: i === 3 ? 10 : 0 })),
    sniffle: () => {
      noise(0.07, { vol: 0.1, freq: 2600, q: 3 });
      noise(0.09, { vol: 0.1, freq: 2300, q: 3, at: 0.12 });
    },
    phew: () => {
      noise(0.35, { vol: 0.1, freq: 1300, to: 500 });
      tone(640, 0.25, { type: "sine", vol: 0.18, to: 420, at: 0.05 });
    },
    tape: () => tone(rnd(220, 260), 0.06, { type: "square", vol: 0.05 }),
    // long waits, results, helpers
    snore: () => {
      noise(1.1, { vol: 0.07, freq: 300, to: 520, kind: "lowpass" });
      tone(95, 1.1, { type: "sawtooth", vol: 0.03, to: 110, vibrato: 6 });
    },
    yawn: () => tone(520, 0.9, { type: "triangle", vol: 0.16, to: 230, vibrato: 8 }),
    crunch: () => [0, 0.09, 0.2, 0.27].forEach((at) => noise(0.07, { vol: 0.22, freq: rnd(700, 1400), q: 2, at })),
    ding: () => {
      tone(1568, 0.6, { type: "sine", vol: 0.2 });
      tone(2093, 0.5, { type: "sine", vol: 0.08, at: 0.01 });
    },
    scribble: () => [0, 0.07, 0.16].forEach((at) => noise(0.05, { vol: 0.1, freq: rnd(3e3, 4200), q: 4, at })),
    rustle: () => noise(0.25, { vol: 0.12, freq: 1800, to: 1100, q: 1.5 }),
    dink: () => {
      tone(2350, 0.12, { type: "sine", vol: 0.3, to: 2250 });
      tone(3520, 0.08, { type: "sine", vol: 0.12 });
      tone(5100, 0.05, { type: "sine", vol: 0.05 });
    },
    fork: () => {
      tone(260, 0.55, { type: "triangle", vol: 0.18, to: 780, vibrato: 14 });
      noise(0.3, { vol: 0.06, freq: 1200, to: 3e3, at: 0.3 });
    },
    bubble: () => [0, 0.08, 0.15].forEach((at) => tone(rnd(500, 900), 0.06, { type: "sine", vol: 0.14, to: rnd(1100, 1500), at })),
    click: () => tone(rnd(1900, 2200), 0.02, { type: "square", vol: 0.05 }),
    yes: () => {
      tone(523, 0.08, { type: "square", vol: 0.14 });
      tone(784, 0.08, { type: "square", vol: 0.14, at: 0.09 });
      tone(1047, 0.22, { type: "square", vol: 0.14, at: 0.18 });
    },
    facepalm: () => {
      noise(0.06, { vol: 0.3, freq: 900, q: 1 });
      tone(330, 0.5, { type: "triangle", vol: 0.18, to: 196, at: 0.12 });
    }
  };
  var ACTION_SOUNDS = {
    paint: ["swish", 900],
    canvas: ["swish", 900],
    spray: ["psst", 500],
    erase: ["squeak", 320],
    remove: ["vacuum", 1050],
    write: ["tick", 280],
    font: ["boing", 1e3],
    build: ["bonk", 700],
    measure: ["zip", 1600],
    add: ["chime", 1200],
    wire: ["zap", 450],
    hack: ["blip", 240],
    watch: ["hmm", 2e3],
    dance: ["note", 250],
    photo: ["shutter", 1600],
    stash: ["creak", 1600],
    polish: ["shimmer", 1e3],
    search: ["sonar", 1300],
    read: ["flip", 1400],
    think: ["thought", 1200],
    fetch: ["step", 320],
    tinker: ["bonk", 1200],
    wave: ["dingdong", 8e3],
    sad: ["sniffle", 2600],
    test: ["tick", 800],
    lab: ["bubble", 700],
    compile: ["bonk", 700],
    install: ["rustle", 1100],
    mail: ["whoosh", 1800],
    ponder: ["scribble", 1700],
    wait: ["flip", 5e3],
    knit: ["click", 380],
    doze: ["snore", 3200],
    timer: ["click", 160],
    compact: ["crunch", 1300]
  };
  var SOUND_NAMES = Object.keys(SOUNDS);

  // src/fiber.js
  function findComponentNode(names, raw, visible) {
    if (!names || !names.length) return null;
    const want = new Set(names);
    let rootFiber = null;
    for (const n of [document.getElementById("root"), document.getElementById("app"), document.body, ...document.body ? document.body.children : []]) {
      const w = raw(n);
      if (!w) continue;
      let key;
      try {
        key = Object.keys(w).find((k) => k.startsWith("__reactContainer$"));
      } catch {
      }
      if (key) {
        rootFiber = w[key];
        break;
      }
    }
    if (!rootFiber) return null;
    const nameOf = (f) => {
      const t = f && f.type;
      if (!t || typeof t === "string") return "";
      return t.displayName || t.name || t.render && (t.render.displayName || t.render.name) || t.type && (t.type.displayName || t.type.name) || "";
    };
    const hostNode = (f) => {
      for (let q = f, i = 0; q && i < 200; i++) {
        if (q.tag === 5 && q.stateNode && visible(q.stateNode)) return q.stateNode;
        q = q.child || (q === f ? null : nextOf(q, f));
      }
      return null;
    };
    const nextOf = (q, stop) => {
      while (q && q !== stop) {
        if (q.sibling) return q.sibling;
        q = q.return;
      }
      return null;
    };
    const found = /* @__PURE__ */ new Map();
    const stack = [rootFiber.current || rootFiber];
    for (let seen = 0; stack.length && seen < 3e4 && found.size < want.size; seen++) {
      const f = stack.pop();
      if (!f) continue;
      const nm = nameOf(f);
      if (want.has(nm) && !found.has(nm)) {
        const n = hostNode(f.child || f);
        if (n) found.set(nm, n);
      }
      if (f.sibling) stack.push(f.sibling);
      if (f.child) stack.push(f.child);
    }
    for (const nm of names) if (found.has(nm)) return found.get(nm);
    return null;
  }

  // src/api.js
  var api = globalThis.browser || globalThis.chrome;
  var FIREFOX = typeof globalThis.browser !== "undefined" && !!globalThis.browser.runtime.getBrowserInfo;

  // src/overlay.js
  function install() {
    const SCALE = 1.5;
    const SPRITE_W = 96 * SCALE;
    const LABEL_SCALE = 1.25;
    const UNIT = SPRITE_W / VIEWBOX.w;
    const SPRITE_H = Math.round(UNIT * VIEWBOX.h);
    const FOOT_X = (8 - VIEWBOX.x) * UNIT;
    const FOOT_Y = (10 - VIEWBOX.y) * UNIT;
    const HAND = { x: 6 * UNIT, y: 5 * UNIT };
    const SPEED = 420;
    const RUN = 900;
    const BELOW = 16 * SCALE;
    const NEAR = 190;
    const GUESS_MS = 2200;
    const HOLD_MS = 10 * 6e4;
    const SIT_AFTER = 2e4;
    const DOZE_AFTER = 18e4;
    const PONDER_AFTER = 12e3;
    const REACT_MS = 1800;
    const MINI_W = 46 * SCALE;
    const MINI_SPEED = 260 * SCALE;
    const EYES = eyeOffset(SPRITE_W);
    const TICKLES = ["Hehe!", "Hahaha, stop it!", "I\u2019m trying to work here!", "OK OK, you win!"];
    const STYLE = `
:host { all: initial; }
* { box-sizing: border-box; }
.layer { position: fixed; inset: 0; pointer-events: none; overflow: hidden; font: ${12 * SCALE}px/1.3 system-ui, sans-serif;
  --clawd: #d97757; --clawd-eye: #1f1e1d; --accent: #d97757; }
/* the thing he's working on: a soft glow that glides between targets */
.glow { position: absolute; left: 0; top: 0; border-radius: 12px; opacity: 0; transition: opacity .35s;
  border: 2px solid color-mix(in srgb, var(--accent) 65%, transparent);
  background: color-mix(in srgb, var(--accent) 6%, transparent);
  box-shadow: 0 0 22px 3px color-mix(in srgb, var(--accent) 35%, transparent); will-change: transform, width, height; }
.glow.on { opacity: 1; }
.glow.ok { border-color: rgba(79, 154, 69, .8); box-shadow: 0 0 22px 3px rgba(79, 154, 69, .4); }
.fxbox { position: absolute; left: 0; top: 0; overflow: hidden; border-radius: 10px; opacity: 0; transition: opacity .3s; }
.fxbox.on { opacity: 1; }
.fx { position: absolute; inset: 0; }
.cover { position: absolute; left: 0; top: 0; transform-origin: 0 0; clip-path: inset(0 0 0 0); }
.sprite { position: absolute; left: 0; top: 0; width: ${SPRITE_W}px; height: ${SPRITE_H}px; will-change: transform;
  filter: drop-shadow(0 2px 2px rgba(0,0,0,.25)); }
.turn { position: absolute; inset: 0; transition: transform .15s; }
.turn.flip { transform: scaleX(-1); }
.turn.flip .cw-sign-text { transform: scaleX(-1); transform-origin: 16.7px 0; } /* keep signs readable */
.hit { position: absolute; left: ${(3 - VIEWBOX.x) * UNIT}px; top: ${(0 - VIEWBOX.y) * UNIT}px;
  width: ${10 * UNIT}px; height: ${10 * UNIT}px; pointer-events: auto; cursor: pointer; }
.label { position: absolute; left: 50%; bottom: calc(100% + 2px); transform: translate(-50%, 67%); white-space: nowrap;
  font-size: ${12 * LABEL_SCALE}px; max-width: ${280 * LABEL_SCALE}px; overflow: hidden; text-overflow: ellipsis;
  padding: ${3 * LABEL_SCALE}px ${9 * LABEL_SCALE}px; border-radius: ${10 * LABEL_SCALE}px;
  background: #1f1e1d; color: #faf9f5; box-shadow: 0 2px 6px rgba(0,0,0,.2); }
.label:empty { display: none; }
/* standing below what he's changing: the caption goes under him, out of its way */
.label.under { bottom: auto; top: calc(100% - ${2 * SCALE}px); transform: translateX(-50%); }
.tag { position: absolute; left: 50%; top: calc(100% + 1px); transform: translateX(-50%); white-space: nowrap;
  font-size: ${10 * SCALE}px; font-weight: 600; color: #faf9f5; background: var(--clawd); border-radius: ${7 * SCALE}px; padding: 0 ${6 * SCALE}px; opacity: .92; }
.tag:empty { display: none; }
.mini { position: absolute; left: 0; top: 0; width: ${MINI_W}px; height: ${Math.round(MINI_W * VIEWBOX.h / VIEWBOX.w)}px;
  transition-property: transform, opacity; transition-timing-function: linear; will-change: transform;
  filter: drop-shadow(0 1px 1px rgba(0,0,0,.25)); }
.mini.gone { opacity: 0; transition-duration: .4s !important; }
/* babies: toddle, wobble, and the odd tumble */
@keyframes toddle { 0%, 100% { transform: rotate(-6deg); } 50% { transform: rotate(6deg) translateY(-${SCALE}px); } }
@keyframes plop { 0% { transform: none; } 25% { transform: rotate(-75deg) translate(-${4 * SCALE}px, ${6 * SCALE}px); }
  70% { transform: rotate(-75deg) translate(-${4 * SCALE}px, ${6 * SCALE}px); } 100% { transform: none; } }
.derp { position: absolute; inset: 0; transform-origin: 50% 85%; animation: toddle 1.3s ease-in-out infinite; }
.derp.plop { animation: plop 1.4s cubic-bezier(.3, 1.4, .5, 1) 1; }
.minitag { position: absolute; left: 50%; top: calc(100% + 1px); transform: translateX(-50%); white-space: nowrap;
  font-size: ${9 * SCALE}px; font-weight: 600; color: #faf9f5; background: var(--clawd); border-radius: ${6 * SCALE}px; padding: 0 ${5 * SCALE}px; opacity: .9; }
.minitag:empty { display: none; }

/* effects inside the highlight box */
.fx { position: absolute; inset: 0; }
@keyframes sweep { 0% { transform: scaleX(0); opacity: .35; } 70% { transform: scaleX(1); opacity: .3; } 100% { transform: scaleX(1); opacity: 0; } }
.wash { position: absolute; inset: 0; transform-origin: left; animation: sweep 1.8s ease-in-out infinite; }
@keyframes drip { 0% { transform: translateY(-10px); opacity: 0; } 20% { opacity: 1; } 100% { transform: translateY(40px); opacity: 0; } }
.drop { position: absolute; top: 0; width: 6px; height: 9px; border-radius: 50% 50% 50% 50% / 60% 60% 40% 40%; animation: drip 1.4s ease-in infinite; }
@keyframes mist { 0% { transform: scale(.2); opacity: .8; } 100% { transform: scale(1.4); opacity: 0; } }
.puff { position: absolute; width: 22px; height: 22px; border-radius: 50%; filter: blur(3px); animation: mist 1.1s ease-out infinite; }
@keyframes fade { 0%, 100% { opacity: 0; } 50% { opacity: .45; } }
.stripes { position: absolute; inset: 0; background: repeating-linear-gradient(-45deg, rgba(250,249,245,.8) 0 8px, transparent 8px 16px); animation: fade 1.2s infinite; }
@keyframes fall { 0% { transform: translateY(0); opacity: 1; } 100% { transform: translateY(30px); opacity: 0; } }
.dust { position: absolute; bottom: 4px; width: 4px; height: 4px; background: #b9b5aa; animation: fall .9s ease-in infinite; }
@keyframes suck { 0% { transform: translate(0, 0) scale(1); opacity: 1; } 100% { transform: translate(var(--dx), var(--dy)) scale(.2); opacity: 0; } }
.bit { position: absolute; width: 8px; height: 8px; background: var(--accent); border-radius: 2px; animation: suck 1s ease-in infinite; }
@keyframes blink { 0%, 100% { opacity: 0; } 50% { opacity: 1; } }
.caret { position: absolute; left: 8px; top: 8px; width: 2px; height: 18px; background: #1f1e1d; animation: blink .8s steps(1) infinite; }
@keyframes pop { 0% { transform: translateY(6px) scale(.5); opacity: 0; } 30% { transform: none; opacity: 1; } 100% { transform: translateY(-14px); opacity: 0; } }
.glyph { position: absolute; font: 700 16px Georgia, serif; color: #1f1e1d; animation: pop 1.6s ease-out infinite; }
@keyframes wobble { 0%, 100% { transform: scale(1); } 30% { transform: scale(1.02, .98); } 60% { transform: scale(.99, 1.01); } }
.fxbox.wobble { animation: wobble .7s infinite; }
.star { position: absolute; font-size: 16px; color: #f2c94c; animation: blink .7s steps(2) infinite; text-shadow: 0 0 4px #fff; }
.ruler { position: absolute; left: 0; right: 0; top: 50%; height: 0; border-top: 2px solid #3a7bd5; }
.ruler::before, .ruler::after { content: ""; position: absolute; top: -7px; width: 2px; height: 12px; background: #3a7bd5; }
.ruler::before { left: 0; } .ruler::after { right: 0; }
.measure { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -130%); background: #3a7bd5; color: #fff; padding: 2px 7px; border-radius: 6px; font: 600 11px ui-monospace, Consolas, monospace; }
.plus { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); font: 700 28px system-ui; color: var(--accent); animation: blink 1s infinite; }
@keyframes rain { 0% { transform: translateY(-100%); } 100% { transform: translateY(100vh); } }
.matrix { position: absolute; inset: 0; background: rgba(0, 20, 6, .55); }
.col { position: absolute; top: 0; font: 12px/1 ui-monospace, Consolas, monospace; color: #36d15e; text-shadow: 0 0 4px #36d15e; writing-mode: vertical-rl; animation: rain 2.2s linear infinite; }
@keyframes ping { 0% { transform: translate(-50%, -50%) scale(0); opacity: .8; } 100% { transform: translate(-50%, -50%) scale(1); opacity: 0; } }
.radar { position: absolute; left: 50%; top: 50%; width: 160%; aspect-ratio: 1; border: 2px solid #4f9a45; border-radius: 50%; animation: ping 1.8s ease-out infinite; }
@keyframes bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-4px); } }
.fxbox.bounce { animation: bounce .5s ease-in-out infinite; }
.note { position: absolute; font-size: 18px; color: var(--accent); animation: pop 1.4s ease-out infinite; }
@keyframes flash { 0%, 80%, 100% { opacity: 0; } 84% { opacity: .9; } }
.flash { position: absolute; inset: 0; background: #fff; animation: flash 1.6s infinite; }
@keyframes scanline { 0% { top: 0; } 100% { top: 100%; } }
.scan { position: absolute; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, transparent, var(--accent), transparent); box-shadow: 0 0 8px var(--accent); animation: scanline 1.3s ease-in-out infinite alternate; }
.spark { position: absolute; font-size: 15px; animation: blink .35s steps(2) infinite; }
.gear { position: absolute; right: 6px; top: 6px; font-size: 18px; color: #6b7078; animation: spin 2s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.ok-tick { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); font: 700 30px system-ui; color: #4f9a45; }
${CLAWD_CSS}`;
    const COLORS = ["#d97757", "#5b8fd9", "#4fa36b", "#a777d6", "#d9a13b", "#d0607e"];
    let host, layer;
    let raf = 0;
    let lastT = 0;
    const clawds = /* @__PURE__ */ new Map();
    let colorIx = 0;
    let stepSeq = 0;
    let mouse = null;
    window.addEventListener("mousemove", (e) => {
      mouse = { x: e.clientX, y: e.clientY };
    }, { passive: true, capture: true });
    const sfxAt = /* @__PURE__ */ new Map();
    function sfx(name) {
      const now = performance.now();
      if (document.visibilityState !== "visible" || now - (sfxAt.get(name) || 0) < 60) return;
      sfxAt.set(name, now);
      try {
        api.runtime.sendMessage({ cmd: "ClawdSound", data: { name } }).catch(() => {
        });
      } catch {
      }
    }
    const BROKEN_SAY = {
      build: "Oh no\u2026 the build broke",
      blank: "Oh no\u2026 the page went blank",
      error: "Oh no\u2026 something threw an error"
    };
    let lastPageError = -Infinity;
    let rootSeen = false;
    let broken = "";
    let brokenCheckAt = 0;
    window.addEventListener("error", (e) => {
      if (e && (e.error || e.message)) lastPageError = performance.now();
    }, true);
    window.addEventListener("unhandledrejection", () => {
      lastPageError = performance.now();
    }, true);
    function brokenReason(now) {
      if (document.querySelector("vite-error-overlay, nextjs-portal, #webpack-dev-server-client-overlay, react-error-overlay")) return "build";
      const root = document.getElementById("root") || document.getElementById("app") || document.getElementById("__next");
      if (root) {
        if (root.childElementCount) rootSeen = true;
        else if (rootSeen) return "blank";
      }
      return now - lastPageError < 4e3 ? "error" : "";
    }
    function checkBroken(now) {
      if (now < brokenCheckAt) return;
      brokenCheckAt = now + 400;
      const next = brokenReason(now);
      if (next === broken) return;
      const was = broken;
      broken = next;
      for (const c of [...clawds.values()]) {
        if (!c.live) continue;
        if (next && !was) {
          sfx("sad");
          c.nextSfx = now + 2600;
        } else if (!next) {
          sfx("phew");
          setLabel(c, "Phew, fixed!");
          c.phewUntil = now + 1500;
        }
      }
    }
    document.addEventListener("mouseleave", () => {
      mouse = null;
    }, { passive: true });
    const el = (tag, cls, parent, text) => {
      const n = document.createElement(tag);
      if (cls) n.className = cls;
      if (text != null) n.textContent = text;
      if (parent) parent.appendChild(n);
      return n;
    };
    const vp = () => ({ w: window.innerWidth, h: window.innerHeight });
    const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
    function ensureLayer() {
      if (!host) {
        host = document.createElement("live-clawd-overlay");
        const st = host.style;
        st.setProperty("all", "initial", "important");
        st.setProperty("position", "fixed", "important");
        st.setProperty("inset", "0", "important");
        st.setProperty("z-index", "2147483647", "important");
        st.setProperty("pointer-events", "none", "important");
        st.setProperty("display", "block", "important");
        const root = host.attachShadow({ mode: "closed" });
        el("style", null, root, STYLE);
        layer = el("div", "layer", root);
      }
      if (!host.isConnected) document.documentElement.appendChild(host);
      if (!raf) {
        lastT = performance.now();
        raf = requestAnimationFrame(tick);
      }
    }
    function hideAll() {
      cancelAnimationFrame(raf);
      raf = 0;
      for (const c of [...clawds.values()]) dropDom(c);
      clawds.clear();
      if (host) host.remove();
    }
    function dropDom(c) {
      for (const n of [c.root, c.glow, c.box, ...c.ghosts, ...[...c.helpers.values()].map((h) => h.node)]) n.remove();
    }
    function reportGone(c) {
      try {
        if (typeof browser !== "undefined") {
          api.runtime.sendMessage({ cmd: "ClawdGone", data: { id: c.id, dismissed: !!c.dismissed } }).catch(() => {
          });
        }
      } catch {
      }
    }
    function removeClawd(c) {
      dropDom(c);
      clawds.delete(c.id);
      reportGone(c);
      if (!clawds.size) hideAll();
    }
    function setColor(c, color) {
      if (!color || color === c.color) return;
      c.color = color;
      c.root.style.setProperty("--clawd", color);
      c.glow.style.setProperty("--accent", color);
      c.box.style.setProperty("--accent", color);
    }
    function getClawd(id, msg) {
      let c = clawds.get(id);
      if (!c) {
        const glow = el("div", "glow", layer);
        const box = el("div", "fxbox", layer);
        const root = el("div", "sprite", layer);
        const turn = el("div", "turn", root);
        const svg = clawdSpriteNode(document, SPRITE_W);
        turn.appendChild(svg);
        const hit = el("div", "hit", root);
        c = {
          id,
          glow,
          box,
          root,
          turn,
          svg,
          fx: el("div", "fx", box),
          hl: box,
          // effects() animates this one
          label: el("div", "label", root),
          tagEl: el("div", "tag", root),
          queue: [],
          cur: null,
          ghosts: [],
          helpers: /* @__PURE__ */ new Map(),
          priority: [],
          pos: null,
          mood: "idle",
          extra: "",
          idleMood: "idle",
          glowRect: null,
          boxRect: null,
          leaving: false,
          endAfterQueue: null,
          lastWork: 0,
          waterUntil: 0,
          nextWater: 0,
          throwUntil: 0,
          tickleUntil: 0,
          tickles: 0,
          lastTickle: 0,
          noticeUntil: 0,
          near: false,
          offset: clawds.size % 3 * 44 * SCALE
          // later Clawds stand a little to the side
        };
        const stop = (e) => {
          e.stopPropagation();
          e.preventDefault();
        };
        hit.addEventListener("mousedown", stop);
        hit.addEventListener("click", (e) => {
          stop(e);
          click(c);
        });
        clawds.set(id, c);
        setColor(c, msg.color || COLORS[colorIx++ % COLORS.length]);
      }
      if (msg.color) setColor(c, msg.color);
      if (msg.live) c.live = true;
      return c;
    }
    function visible(n) {
      if (!n || n === host || !n.getBoundingClientRect) return false;
      const r = n.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) return false;
      const cs = getComputedStyle(n);
      return cs.visibility !== "hidden" && cs.display !== "none";
    }
    function firstVisible(sel) {
      let list;
      try {
        list = document.querySelectorAll(sel);
      } catch {
        return null;
      }
      for (const n of list) if (visible(n)) return n;
      return null;
    }
    function findByText(text) {
      if (!text || text.length < 3) return null;
      const needle = text.toLowerCase();
      const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
      for (let n = walker.nextNode(), i = 0; n && i < 2e4; n = walker.nextNode(), i++) {
        if (n.data.toLowerCase().includes(needle) && visible(n.parentElement)) return n.parentElement;
      }
      return null;
    }
    function findByComponent(names) {
      if (!names || !names.length) return null;
      if (document.documentElement.wrappedJSObject) {
        return findComponentNode(names, (n2) => n2 && (n2.wrappedJSObject || n2), visible);
      }
      const token = Math.random().toString(36).slice(2);
      document.dispatchEvent(new CustomEvent("clawd-find", { detail: JSON.stringify({ names, token }) }));
      const n = document.querySelector(`[data-clawd-found="${token}"]`);
      if (n) n.removeAttribute("data-clawd-found");
      return n;
    }
    function resolve(step) {
      const t = step.target || {};
      const tries = [];
      if (t.testid) tries.push(() => firstVisible(`[data-testid="${CSS.escape(t.testid)}"]`));
      if (t.selector) tries.push(() => firstVisible(t.selector));
      if (t.component) tries.push(() => findByComponent([t.component]));
      if (t.text) tries.push(() => findByText(t.text));
      for (const s of step.selectors || []) tries.push(() => firstVisible(s));
      if (step.components && step.components.length) tries.push(() => findByComponent(step.components));
      if (step.pattern) {
        tries.push(() => firstVisible(step.pattern));
        for (const tok of (step.pattern.match(/[A-Za-z][\w-]{2,}/g) || []).slice(0, 6)) {
          tries.push(() => firstVisible(`#${CSS.escape(tok)}`) || firstVisible(`.${CSS.escape(tok)}`) || firstVisible(`[class*="${tok}" i]`) || firstVisible(`[id*="${tok}" i]`));
        }
        tries.push(() => findByText(step.pattern.replace(/\\[sdwb]|[\\^$.*+?()[\]{}|]/g, " ").trim().split(/\s{2,}/)[0]));
      }
      for (const f of tries) {
        try {
          const n = f();
          if (n) return n;
        } catch {
        }
      }
      return null;
    }
    const hasTarget = (step) => {
      const t = step.target || {};
      return !!(t.testid || t.selector || t.component || t.text || (step.selectors || []).length || (step.components || []).length || step.pattern);
    };
    function stepRect(step) {
      if (step.el && step.el.isConnected) {
        step.rect = step.el.getBoundingClientRect();
        step.gone = false;
      } else if (step.el && step.rect) {
        step.gone = true;
      }
      return step.rect || null;
    }
    function stepPoint(step, r) {
      const t = step.target || {};
      if (!r || t.x == null || t.y == null) return null;
      return { x: r.left + clamp(t.x, 0, 1) * r.width, y: r.top + clamp(t.y, 0, 1) * r.height };
    }
    function besideRect(c, r, w, h) {
      const half = 8 * UNIT;
      const tall = 10 * UNIT;
      const gap = 8 * SCALE;
      const sideY = Math.min(r.bottom, r.top + tall + 4);
      const top = FOOT_Y + 26 * SCALE;
      if (r.right + gap + 2 * half <= w) return { fx: r.right + gap + half, fy: sideY };
      if (r.left - gap - 2 * half >= 0) return { fx: r.left - gap - half, fy: sideY };
      const midX = r.left + Math.min(r.width / 2, 80 * SCALE) + c.offset;
      if (r.bottom + gap + tall <= h - BELOW - 30 * SCALE) return { fx: midX, fy: r.bottom + gap + tall, under: true };
      if (r.top - gap >= top) return { fx: midX, fy: r.top - gap };
      return {
        fx: r.left + Math.min(56 * SCALE, r.width / 2) + c.offset,
        fy: r.top > SPRITE_H + 24 * SCALE ? r.top + 4 : Math.min(r.bottom, r.top + SPRITE_H + 12 * SCALE)
      };
    }
    function destination(c) {
      const { w, h } = vp();
      if (c.leaving && !c.cur && !c.queue.length) {
        const exitLeft = c.pos && c.pos.x + FOOT_X < w / 2;
        return { x: exitLeft ? -SPRITE_W - 20 : w + 20, y: c.pos ? c.pos.y : h - BELOW - FOOT_Y };
      }
      const step = c.cur;
      const r = step && stepRect(step);
      let under = false;
      let fx;
      let fy;
      const pt = step && stepPoint(step, r);
      if (pt) {
        fx = pt.x - HAND.x;
        fy = pt.y + HAND.y;
      } else if (r) {
        ({ fx, fy, under } = besideRect(c, r, w, h));
      } else {
        fx = w - 70 * SCALE - c.offset * 2;
        fy = h - BELOW;
      }
      c.label.classList.toggle("under", !!under);
      fx = clamp(fx, FOOT_X + 4, w - (SPRITE_W - FOOT_X) - 4);
      fy = clamp(fy, FOOT_Y + 26 * SCALE, h - BELOW);
      return { x: fx - FOOT_X, y: fy - FOOT_Y };
    }
    const lerpRect = (a, b, k) => a ? {
      left: a.left + (b.left - a.left) * k,
      top: a.top + (b.top - a.top) * k,
      width: a.width + (b.width - a.width) * k,
      height: a.height + (b.height - a.height) * k
    } : { ...b };
    const place = (n, r) => {
      n.style.transform = `translate(${Math.round(r.left)}px, ${Math.round(r.top)}px)`;
      n.style.width = `${Math.round(r.width)}px`;
      n.style.height = `${Math.round(r.height)}px`;
    };
    function placeGlow(c, working) {
      const step = c.cur;
      const r = working && step && step.rect;
      const { w, h } = vp();
      if (!r) {
        c.glow.classList.remove("on");
        c.box.classList.remove("on");
        return;
      }
      const pt = stepPoint(step, r);
      let g = pt ? { left: pt.x - 26 * SCALE, top: pt.y - 26 * SCALE, width: 52 * SCALE, height: 52 * SCALE } : { left: r.left - 6, top: r.top - 6, width: r.width + 12, height: r.height + 12 };
      g = { left: clamp(g.left, 2, w - 10), top: clamp(g.top, 2, h - 10), width: Math.min(g.width, w - 4), height: Math.min(g.height, h - 4) };
      c.glowRect = lerpRect(c.glowRect, g, 0.22);
      place(c.glow, c.glowRect);
      c.glow.style.borderRadius = pt ? "50%" : "12px";
      c.glow.classList.toggle("on", !step.gone || !!step.cover);
      const hx = pt ? pt.x : c.pos.x + FOOT_X + HAND.x;
      const hy = pt ? pt.y : c.pos.y + FOOT_Y - HAND.y;
      const bw = Math.min(r.width, 220);
      const bh = Math.min(r.height, 130);
      const b = {
        left: clamp(hx - bw / 2, r.left, r.right - bw),
        top: clamp(hy - bh / 2, r.top, r.bottom - bh),
        width: bw,
        height: bh
      };
      c.boxRect = lerpRect(c.boxRect, b, 0.22);
      place(c.box, c.boxRect);
      c.box.classList.add("on");
    }
    function setLabel(c, text) {
      text = plainSay(text);
      if (c.label.textContent === text) return;
      c.label.textContent = text;
      c.labelW = 0;
    }
    function placeLabel(c) {
      if (!c.label.textContent) return;
      if (!c.labelW) c.labelW = c.label.offsetWidth;
      const half = c.labelW / 2;
      const centre = clamp(c.pos.x + SPRITE_W / 2, half + 4, vp().w - half - 4);
      c.label.style.left = `${Math.round(centre - c.pos.x)}px`;
    }
    function show(c, m, now) {
      const extra = [c.tickleUntil > now && "cw-tickle", c.noticeUntil > now && "cw-notice"].filter(Boolean).join(" ");
      if (m === c.mood && extra === c.extra) return;
      c.mood = m;
      c.extra = extra;
      setMood(c.svg, m, extra);
    }
    function click(c) {
      if (c.cur && c.cur.kind === "wave") {
        c.dismissed = true;
        sfx("pop");
        c.queue = [];
        c.cur = { kind: "idle", say: "OK, I\u2019ll wait", ms: 700, id: ++stepSeq };
        c.leaving = true;
        return;
      }
      const now = performance.now();
      if (now - c.lastTickle > 3e3) c.tickles = 0;
      c.lastTickle = now;
      setLabel(c, TICKLES[Math.min(c.tickles++, TICKLES.length - 1)]);
      c.tickleUntil = now + 1300;
      sfx("giggle");
    }
    function watchCursor(c, now) {
      if (!mouse) {
        if (c.near) {
          c.near = false;
          lookAt(c.svg, null);
        }
        return;
      }
      const flip = c.turn.classList.contains("flip");
      const dx = mouse.x - (c.pos.x + (flip ? SPRITE_W - EYES.x : EYES.x));
      const dy = mouse.y - (c.pos.y + EYES.y);
      const near = Math.hypot(dx, dy) < NEAR;
      if (near) {
        if (!c.near && /^(idle|done|think|read)$/.test(c.mood)) {
          c.noticeUntil = now + 350;
          sfx("boop");
        }
        lookAt(c.svg, flip ? -dx : dx, dy);
      } else if (c.near) {
        lookAt(c.svg, null);
      }
      c.near = near;
    }
    function handPos(c) {
      const flip = c.turn.classList.contains("flip");
      const hx = (15 - VIEWBOX.x) * UNIT;
      return { x: c.pos.x + (flip ? SPRITE_W - hx : hx), y: c.pos.y + (1 - VIEWBOX.y) * UNIT, dir: flip ? -1 : 1 };
    }
    const COVER_MAX_MS = 8e3;
    function showCover(c, step, now) {
      if (step.cover || !step.coverSrc) return;
      const img = el("img", "cover");
      layer.insertBefore(img, layer.firstChild);
      img.src = step.coverSrc;
      img.style.width = `${step.crop.width}px`;
      img.style.height = `${step.crop.height}px`;
      step.cover = img;
      step.coverAt = now;
      c.ghosts.push(img);
      placeCover(step);
    }
    function placeCover(step) {
      let x = step.crop.left;
      let y = step.crop.top;
      if (step.el && step.el.isConnected) {
        const r = step.el.getBoundingClientRect();
        x = r.left + step.cropOff.x;
        y = r.top + step.cropOff.y;
        step.crop = { ...step.crop, left: x, top: y };
      }
      step.cover.style.transform = `translate(${x}px, ${y}px)`;
    }
    function reveal(c, step, how) {
      const img = step.cover;
      if (!img || step.revealing) return;
      step.revealing = true;
      const dur = Math.round(Math.min(2200, Math.max(700, (step.ms || 2e3) * 0.7)));
      const st = img.style;
      const hand = handPos(c);
      const fromLeft = hand.x < step.crop.left + step.crop.width / 2;
      switch (how) {
        case "suck":
          sfx("slurp");
          st.transition = "transform 1.1s cubic-bezier(.6, 0, .9, .5), opacity 1.1s ease-in";
          requestAnimationFrame(() => {
            st.transform = `translate(${hand.x}px, ${hand.y}px) scale(.03)`;
            st.opacity = "0";
          });
          break;
        case "wipe":
          st.transition = `clip-path ${dur}ms linear`;
          requestAnimationFrame(() => {
            st.clipPath = fromLeft ? "inset(0 0 0 100%)" : "inset(0 100% 0 0)";
          });
          break;
        case "rub":
          st.transition = `opacity ${dur}ms steps(6), filter ${dur}ms linear`;
          requestAnimationFrame(() => {
            st.opacity = "0";
            st.filter = "blur(3px)";
          });
          break;
        default:
          st.transition = `opacity 900ms ease-in-out ${Math.round(dur * 0.35)}ms`;
          requestAnimationFrame(() => {
            st.opacity = "0";
          });
      }
      setTimeout(() => {
        img.remove();
        c.ghosts = c.ghosts.filter((x) => x !== img);
      }, dur + 1300);
    }
    const revealStyle = (kind) => kind === "remove" ? "suck" : /^(paint|spray)$/.test(kind) ? "wipe" : kind === "erase" ? "rub" : "fade";
    function trackCovers(c, now) {
      for (const st of [c.cur, ...c.queue]) {
        if (!st || !st.cover || st.revealing) continue;
        placeCover(st);
        if (now - st.coverAt > COVER_MAX_MS) reveal(c, st, "fade");
      }
    }
    function begin(c, now) {
      const step = c.queue.shift();
      c.cur = step;
      step.startedAt = now;
      step.arrivedAt = 0;
      if (!step.el && hasTarget(step)) step.el = resolve(step);
      step.retryUntil = !step.el && hasTarget(step) ? now + 4e3 : 0;
      if (step.say != null) setLabel(c, step.say);
      c.pondering = false;
      c.missUntil = 0;
      c.fx.replaceChildren();
      c.glowRect = c.glowRect && step.el ? c.glowRect : null;
      c.glow.classList.remove("ok");
    }
    function arrive(c, now) {
      const step = c.cur;
      step.arrivedAt = now;
      c.nextSfx = 0;
      if (step.kind === "done") sfx("happy");
      else if (step.kind === "error") sfx("sad");
      else if (step.kind === "cheer") sfx("yes");
      else if (step.kind === "facepalm") sfx("facepalm");
      else if (step.kind === "timer") setTimeout(() => c.cur === step && sfx("ding"), 1700);
      const hurry = c.queue.length >= 3 ? 0.5 : 1;
      step.endAt = now + Math.max(900, step.ms * hurry);
      if (step.kind === "done") {
        if (step.rect) c.glow.classList.add("ok");
      } else if (!/^(idle|wave|error|think|test|compile|install|mail|timer|compact|cheer|facepalm)$/.test(step.kind)) {
        effects(c, { kind: step.kind, color: step.color, measure: step.measure });
      }
      if (step.cover) reveal(c, step, revealStyle(step.kind));
    }
    function finishStep(c) {
      const step = c.cur;
      c.cur = null;
      c.fx.replaceChildren();
      if (step && step.cover) reveal(c, step, "fade");
      if (step) c.idleMood = step.kind === "done" || step.kind === "error" ? step.kind : "idle";
      if (!c.queue.length && c.endAfterQueue && c.helpers.size) {
        c.waitBabies = true;
        setLabel(c, "");
      } else if (!c.queue.length && c.endAfterQueue) {
        c.leaving = true;
        setLabel(c, c.idleMood === "error" ? "" : "Bye!");
      } else if (!c.queue.length) {
        setLabel(c, "");
      }
    }
    function walkTo(c, dest, dt) {
      const dx = dest.x - c.pos.x;
      const dy = dest.y - c.pos.y;
      const dist = Math.hypot(dx, dy);
      if (dist <= 2) return false;
      const k = Math.min(dist, (dist > 400 ? RUN : SPEED) * dt);
      c.pos.x += dx / dist * k;
      c.pos.y += dy / dist * k;
      if (Math.abs(dx) > 2) c.turn.classList.toggle("flip", dx < 0);
      c.stepAcc = (c.stepAcc || 0) + dt;
      if (c.stepAcc > 0.17) {
        c.stepAcc = 0;
        sfx("step");
      }
      return true;
    }
    function moping(c, now, dt) {
      const sad = broken && c.live;
      const phew = c.phewUntil > now;
      if (!sad && !phew) {
        if (c.phewUntil) {
          c.phewUntil = 0;
          setLabel(c, c.cur ? c.cur.say || "" : "");
        }
        return false;
      }
      if (c.cur && c.cur.endAt) c.cur.endAt += dt * 1e3;
      if (sad) setLabel(c, BROKEN_SAY[broken]);
      if (walkTo(c, destination(c), dt)) {
        show(c, "walk", now);
      } else {
        if (sad && now > (c.nextSfx || 0)) {
          sfx("sniffle");
          c.nextSfx = now + 2600;
        }
        show(c, sad ? "sad" : "done", now);
      }
      c.glow.classList.remove("on");
      c.box.classList.remove("on");
      c.root.style.transform = `translate(${Math.round(c.pos.x)}px, ${Math.round(c.pos.y)}px)`;
      placeLabel(c);
      return true;
    }
    function update(c, now, dt) {
      if (c.pos && runPriority(c, now, dt)) return;
      if (c.pos && moping(c, now, dt)) return;
      const s = c.cur;
      if (!s && c.queue.length) begin(c, now);
      const cur = c.cur;
      if (cur && cur.retryUntil > now && now > (cur.retryAt || 0)) {
        cur.retryAt = now + 300;
        const t = resolve(cur);
        if (t) {
          cur.el = t;
          cur.retryUntil = 0;
        }
      }
      trackCovers(c, now);
      const dest = destination(c);
      if (!c.pos) {
        const fromLeft = dest.x + FOOT_X < vp().w / 2;
        c.pos = { x: fromLeft ? -SPRITE_W - 10 : vp().w + 10, y: dest.y };
      }
      const dx = dest.x - c.pos.x;
      const dy = dest.y - c.pos.y;
      const dist = Math.hypot(dx, dy);
      const moving = dist > (c.mood === "walk" ? 2 : 30);
      watchCursor(c, now);
      if (c.tickleUntil && now > c.tickleUntil) {
        c.tickleUntil = 0;
        setLabel(c, c.cur ? c.cur.say || "" : "");
      }
      if (moving) {
        const sp = dist > 400 ? RUN : SPEED;
        const k = Math.min(dist, sp * dt);
        c.stepAcc = (c.stepAcc || 0) + dt;
        if (c.stepAcc > (sp === RUN ? 0.11 : 0.17)) {
          c.stepAcc = 0;
          sfx("step");
        }
        c.pos.x += dx / dist * k;
        c.pos.y += dy / dist * k;
        if (Math.abs(dx) > 2) c.turn.classList.toggle("flip", dx < 0);
        show(c, "walk", now);
      } else {
        if (dist > 0.5) {
          c.pos.x += dx * 0.3;
          c.pos.y += dy * 0.3;
        }
        if (c.leaving && !c.cur && !c.queue.length) {
          removeClawd(c);
          return;
        }
        if (cur && !cur.arrivedAt) {
          if (stepPoint(cur, cur.rect)) c.turn.classList.remove("flip");
          else if (cur.rect) c.turn.classList.toggle("flip", cur.rect.left + cur.rect.width / 2 < c.pos.x + FOOT_X);
          arrive(c, now);
        }
        if (cur && now > cur.endAt) finishStep(c);
        else if (cur) {
          c.lastWork = now;
          const mood = cur.hold ? heldMood(c, cur, now) : cur.kind === "paint" && !cur.rect ? "canvas" : moodOf(cur);
          show(c, mood, now);
          const snd = ACTION_SOUNDS[mood];
          if (snd && now > (c.nextSfx || 0) && !cur.rung) {
            sfx(snd[0]);
            c.nextSfx = now + snd[1];
            if (mood === "wave") cur.rung = true;
          }
        } else {
          idle(c, now);
        }
      }
      placeGlow(c, !!(c.cur && c.cur.arrivedAt && !moving));
      c.root.style.transform = `translate(${Math.round(c.pos.x)}px, ${Math.round(c.pos.y)}px)`;
      placeLabel(c);
    }
    function idle(c, now) {
      const busy = now - c.lastWork < 6e4 && !/^(done|error)$/.test(c.idleMood) && !c.leaving;
      if (!c.nextWater) c.nextWater = now + 9e3 + Math.random() * 9e3;
      if (busy && now > c.nextWater && !c.waterUntil && !c.throwUntil) {
        c.waterUntil = now + 3e3;
        [700, 1150, 1600, 2050].forEach((t) => setTimeout(() => c.waterUntil && sfx("glug"), t));
        setTimeout(() => c.waterUntil && sfx("ahh"), 2750);
        setLabel(c, MOOD_LABEL.water);
      }
      if (c.waterUntil && now > c.waterUntil) {
        c.waterUntil = 0;
        c.throwUntil = now + 450;
        c.nextWater = now + 22e3 + Math.random() * 2e4;
      }
      if (c.throwUntil && now > c.throwUntil) {
        c.throwUntil = 0;
        const hand = handPos(c);
        const aim = mouse || { x: hand.x + hand.dir * 260, y: hand.y - 220 };
        tossBottle(document, layer, hand.x, hand.y, aim.x, aim.y, mouse && {
          scale: SCALE,
          cursor: () => mouse,
          onHit: () => sfx("dink"),
          onMiss: () => {
            if (!clawds.has(c.id) || c.cur) return;
            c.missUntil = performance.now() + 2200;
            setLabel(c, DODGED[Math.floor(Math.random() * DODGED.length)]);
            sfx("sniffle");
          }
        });
        sfx("whoosh");
        setLabel(c, "");
      }
      const sulking = c.missUntil > now;
      if (c.missUntil && !sulking) {
        c.missUntil = 0;
        setLabel(c, "");
      }
      const ponder = busy && now - c.lastWork > PONDER_AFTER && !c.waterUntil && !c.throwUntil && !sulking;
      if (ponder && !c.pondering) setLabel(c, MOOD_LABEL.ponder);
      c.pondering = ponder;
      if (ponder && now > (c.nextSfx || 0)) {
        sfx("scribble");
        c.nextSfx = now + 1700;
      }
      show(c, c.waterUntil ? "water" : c.throwUntil ? "throw" : sulking ? "sad" : ponder ? "ponder" : c.idleMood, now);
    }
    function heldMood(c, step, now) {
      const t = now - step.arrivedAt;
      let mood = moodOf(step);
      if (step.kind === "think") {
        if (t > PONDER_AFTER) mood = "ponder";
      } else if (step.kind !== "compact") {
        if (t > DOZE_AFTER) mood = "doze";
        else if (t > SIT_AFTER) mood = step.sit || (step.sit = Math.random() < 0.5 ? "wait" : "knit");
      }
      if (mood === "doze" && !step.dozing) {
        step.dozing = true;
        sfx("yawn");
        c.nextSfx = now + 3e3;
      }
      return mood;
    }
    const VARIANTS = { test: ["test", "lab"] };
    function moodOf(step) {
      const v = VARIANTS[step.kind];
      if (!v) return step.kind;
      if (!step.variant) step.variant = v[Math.floor(Math.random() * v.length)];
      return step.variant;
    }
    function release(c, step, now) {
      if (!step || !step.hold) return;
      step.hold = false;
      if (step.arrivedAt) {
        step.endAt = Math.min(step.endAt, Math.max(now, step.arrivedAt + GUESS_MS));
        if (step.dozing) {
          c.noticeUntil = now + 350;
          sfx("boop");
        }
      } else {
        step.ms = GUESS_MS;
      }
    }
    const ended = /* @__PURE__ */ new Map();
    function endTool(c, msg) {
      const now = performance.now();
      ended.set(msg.toolId, now);
      if (ended.size > 60) ended.delete(ended.keys().next().value);
      const all = [c.cur, ...c.queue];
      const step = all.find((x) => x && x.toolId === msg.toolId && x.hold);
      if (!step) return;
      release(c, step, now);
      const said = TASK_RESULT[step.task];
      if (!said || msg.interrupted) return;
      const react = {
        kind: msg.ok ? "cheer" : "facepalm",
        say: said[msg.ok ? 0 : 1],
        ms: REACT_MS,
        guess: true,
        react: true,
        id: ++stepSeq
      };
      const at = c.queue.indexOf(step);
      c.queue.splice(at + 1, 0, react);
    }
    const BABY_GAP = 10 * SCALE;
    const BABY_ROOM = 24 * SCALE;
    const BABY_IDLE_MS = 15 * 6e4;
    function makeMini(c, label) {
      const node = el("div", "mini", layer);
      node.style.setProperty("--clawd", c.color || "#d97757");
      const turn = el("div", "turn", node);
      const derp = el("div", "derp", turn);
      const svg = clawdSpriteNode(document, MINI_W);
      derp.appendChild(svg);
      const tag = el("div", "minitag", node, label || "");
      return {
        node,
        turn,
        derp,
        svg,
        tag,
        kind: "idle",
        walking: false,
        nextPlop: 0,
        seen: performance.now()
      };
    }
    const MINI_FEET = (10 - VIEWBOX.y) * MINI_W / VIEWBOX.w;
    function walkMini(h, x, y, mood, done) {
      const from = h.at || { x, y };
      const dist = Math.hypot(x - from.x, y - from.y);
      const secs = Math.max(0.3, dist / MINI_SPEED);
      h.turn.classList.toggle("flip", x < from.x);
      setMood(h.svg, mood);
      h.walking = true;
      h.node.style.transitionDuration = "0s";
      h.node.style.transform = `translate(${Math.round(from.x - MINI_W / 2)}px, ${Math.round(from.y - MINI_FEET)}px)`;
      void h.node.offsetWidth;
      h.node.style.transitionDuration = `${secs}s`;
      h.node.style.transform = `translate(${Math.round(x - MINI_W / 2)}px, ${Math.round(y - MINI_FEET)}px)`;
      h.at = { x, y };
      clearTimeout(h.timer);
      h.timer = setTimeout(() => {
        h.walking = false;
        done();
      }, secs * 1e3 + 30);
    }
    function restSpot(c) {
      const { w, h } = vp();
      return { x: clamp(w - 70 * SCALE - c.offset * 2, FOOT_X + 4, w - (SPRITE_W - FOOT_X) - 4), y: h - BELOW };
    }
    function feetOf(c) {
      if (c.pos) return { x: c.pos.x + FOOT_X, y: c.pos.y + FOOT_Y };
      const d = destination(c);
      return { x: d.x + FOOT_X, y: d.y + FOOT_Y };
    }
    function layoutBabies(c) {
      const rest = restSpot(c);
      let edge = rest.x - Math.max(SPRITE_W / 2, c.tagEl.offsetWidth / 2) - BABY_ROOM;
      for (const h of [...c.helpers.values()]) {
        if (h.returning || h.unborn) continue;
        const half = Math.max(MINI_W / 2, h.tag.offsetWidth / 2);
        const x = Math.max(half + 2, edge - half);
        edge = x - half - BABY_GAP;
        if (h.slot && h.slot.x === x && h.slot.y === rest.y) continue;
        h.slot = { x, y: rest.y };
        walkMini(h, x, rest.y, "walk", () => {
          h.turn.classList.remove("flip");
          setMood(h.svg, h.kind);
        });
      }
    }
    const FORK_MS = 1500;
    const FORK_BORN = 0.73;
    function runPriority(c, now, dt) {
      const p = c.priority[0];
      if (!p) return false;
      const feet = c.pos.x + FOOT_X;
      if (feet < FOOT_X || feet > vp().w - FOOT_X) return false;
      if (!p.startedAt) {
        p.startedAt = now;
        c.mood = "";
        setMood(c.svg, "idle");
        void c.svg.getBoundingClientRect();
        if (p.say != null) setLabel(c, p.say);
        if (p.start) p.start(now);
      }
      if (c.cur && c.cur.endAt) c.cur.endAt += dt * 1e3;
      show(c, p.mood, now);
      c.glow.classList.remove("on");
      c.box.classList.remove("on");
      c.root.style.transform = `translate(${Math.round(c.pos.x)}px, ${Math.round(c.pos.y)}px)`;
      placeLabel(c);
      const t = now - p.startedAt;
      if (p.mid && !p.midDone && t > p.midAt) {
        p.midDone = true;
        p.mid(now);
      }
      if (p.ms && t > p.ms || p.done || t > (p.maxMs || 1e4)) {
        c.priority.shift();
        setLabel(c, c.cur ? c.cur.say || "" : "");
        if (p.end) p.end(now);
      }
      return true;
    }
    function helper(c, msg) {
      const key = String(msg.agentId || "");
      let h = c.helpers.get(key);
      if (msg.on === false) {
        if (!h || h.returning) return;
        h.returning = true;
        layoutBabies(c);
        const p = {
          mood: "expect",
          say: "Ooh, results!",
          maxMs: 9e3,
          start: () => {
            const home = feetOf(c);
            const side = c.turn.classList.contains("flip") ? 1 : -1;
            h.turn.classList.toggle("flip", side > 0);
            walkMini(h, home.x + side * (SPRITE_W / 2 - 6 * SCALE), home.y, "fetch", () => {
              p.done = true;
            });
          },
          end: () => {
            setMood(h.svg, "done");
            sfx("chime");
            c.priority.unshift({
              mood: "accept",
              say: "Thanks, little one!",
              ms: 1600,
              end: () => {
                h.node.classList.add("gone");
                setTimeout(() => dropBaby(c, key), 450);
              }
            });
          }
        };
        c.priority.push(p);
        return;
      }
      if (!h) {
        h = makeMini(c, msg.on ? msg.label : "");
        h.unborn = true;
        h.node.style.visibility = "hidden";
        c.helpers.set(key, h);
        c.priority.push({
          mood: "fork",
          say: "Forking a helper",
          ms: FORK_MS,
          midAt: FORK_MS * FORK_BORN,
          start: () => sfx("fork"),
          mid: () => {
            const flip = c.turn.classList.contains("flip");
            const feet = feetOf(c);
            h.at = { x: feet.x + (flip ? 1 : -1) * 10 * UNIT, y: feet.y };
            h.node.style.transitionDuration = "0s";
            h.node.style.transform = `translate(${Math.round(h.at.x - MINI_W / 2)}px, ${Math.round(h.at.y - MINI_FEET)}px)`;
            h.node.style.visibility = "";
            h.unborn = false;
            sfx("pop");
            layoutBabies(c);
          }
        });
      }
      h.seen = performance.now();
      if (msg.kind) {
        h.kind = msg.kind;
        if (!h.walking && !h.unborn && !h.returning) setMood(h.svg, h.kind);
      }
    }
    function dropBaby(c, key) {
      const h = c.helpers.get(key);
      if (h) {
        clearTimeout(h.timer);
        h.node.remove();
      }
      c.helpers.delete(key);
      if (!c.helpers.size && c.waitBabies && c.endAfterQueue && !c.cur && !c.queue.length) {
        c.waitBabies = false;
        c.leaving = true;
        setLabel(c, c.idleMood === "error" ? "" : "Bye!");
      }
    }
    function tickBabies(c, now) {
      for (const [key, h] of [...c.helpers]) {
        if (h.returning || h.unborn) continue;
        if (now - h.seen > BABY_IDLE_MS) {
          dropBaby(c, key);
          continue;
        }
        if (!h.nextPlop) h.nextPlop = now + 6e3 + Math.random() * 1e4;
        if (now > h.nextPlop && !h.walking) {
          h.nextPlop = now + 8e3 + Math.random() * 14e3;
          h.derp.classList.remove("plop");
          void h.derp.offsetWidth;
          h.derp.classList.add("plop");
          setTimeout(() => sfx("squeak"), 350);
        }
      }
    }
    function tick(now) {
      raf = requestAnimationFrame(tick);
      const dt = Math.min(0.05, (now - lastT) / 1e3);
      lastT = now;
      if ([...clawds.values()].some((c) => c.live)) checkBroken(now);
      for (const c of [...clawds.values()]) {
        update(c, now, dt);
        if (c.helpers.size) tickBabies(c, now);
      }
    }
    function effects(c, a) {
      const { fx: fxEl, hl, svg } = c;
      fxEl.replaceChildren();
      hl.classList.remove("wobble", "bounce", "ok");
      const color = a.color && CSS.supports("color", a.color) ? a.color : "#d97757";
      hl.style.setProperty("--paint", color);
      svg.style.setProperty("--paint", color);
      const rnd2 = (min, max) => min + Math.random() * (max - min);
      const at = (n, l, t) => {
        n.style.left = l;
        n.style.top = t;
        return n;
      };
      switch (a.kind) {
        case "paint": {
          el("div", "wash", fxEl).style.background = color;
          for (let i = 0; i < 5; i++) {
            const d = at(el("div", "drop", fxEl), `${10 + i * 19}%`, "0");
            d.style.background = color;
            d.style.animationDelay = `${i * 0.27}s`;
          }
          break;
        }
        case "spray":
          for (let i = 0; i < 7; i++) {
            const p = at(el("div", "puff", fxEl), `${rnd2(5, 90)}%`, `${rnd2(5, 80)}%`);
            p.style.background = color;
            p.style.animationDelay = `${i * 0.16}s`;
          }
          break;
        case "erase":
          el("div", "stripes", fxEl);
          for (let i = 0; i < 6; i++) at(el("div", "dust", fxEl), `${rnd2(5, 95)}%`, "auto").style.animationDelay = `${rnd2(0, 0.9)}s`;
          break;
        case "remove":
          for (let i = 0; i < 9; i++) {
            const b = at(el("div", "bit", fxEl), `${rnd2(20, 90)}%`, `${rnd2(20, 90)}%`);
            b.style.setProperty("--dx", `${-rnd2(40, 160)}px`);
            b.style.setProperty("--dy", `${-rnd2(20, 90)}px`);
            b.style.animationDelay = `${rnd2(0, 1)}s`;
          }
          break;
        case "write":
        case "font": {
          el("div", "caret", fxEl);
          const glyphs = a.kind === "font" ? ["A", "a", "Ag", "Aa"] : ["a", "b", "c", "\u270E"];
          glyphs.forEach((g, i) => {
            const n = at(el("div", "glyph", fxEl, g), `${12 + i * 18}%`, "30%");
            if (a.kind === "font") n.style.fontSize = `${14 + i * 5}px`;
            n.style.animationDelay = `${i * 0.35}s`;
          });
          break;
        }
        case "build":
          hl.classList.add("wobble");
          ["\u2726", "\u2727", "\u2726"].forEach((s, i) => {
            at(el("div", "star", fxEl, s), `${8 + i * 6}%`, `${6 + i * 9}%`).style.animationDelay = `${i * 0.2}s`;
          });
          break;
        case "measure":
          el("div", "ruler", fxEl);
          el("div", "measure", fxEl, a.measure || "\u2194 resizing");
          break;
        case "add":
          el("div", "plus", fxEl, "+");
          for (let i = 0; i < 6; i++) at(el("div", "star", fxEl, "\u2726"), `${rnd2(5, 90)}%`, `${rnd2(5, 80)}%`).style.animationDelay = `${rnd2(0, 0.7)}s`;
          break;
        case "wire":
          [["4%", "6%"], ["86%", "10%"], ["8%", "70%"], ["84%", "74%"]].forEach(([l, t], i) => {
            at(el("div", "spark", fxEl, "\u26A1"), l, t).style.animationDelay = `${i * 0.09}s`;
          });
          break;
        case "hack": {
          el("div", "matrix", fxEl);
          const chars = "\u30A2\u30A4\u30A6\u30A8\u30AA\u30AB\u30AD\u30AF\u30B1\u30B301\uFF8A\uFF8B\uFF8C\uFF8D\uFF8E<>{}#$";
          for (let i = 0; i < 14; i++) {
            let s = "";
            for (let j = 0; j < 14; j++) s += chars[Math.floor(Math.random() * chars.length)];
            const col = at(el("div", "col", fxEl, s), `${i * 7.2}%`, "0");
            col.style.animationDelay = `${-rnd2(0, 2.2)}s`;
            col.style.animationDuration = `${rnd2(1.6, 3)}s`;
          }
          break;
        }
        case "watch":
          el("div", "radar", fxEl);
          el("div", "radar", fxEl).style.animationDelay = ".9s";
          break;
        case "dance":
          hl.classList.add("bounce");
          ["\u266A", "\u266B", "\u266A"].forEach((s, i) => {
            at(el("div", "note", fxEl, s), `${15 + i * 30}%`, "40%").style.animationDelay = `${i * 0.45}s`;
          });
          break;
        case "photo":
          el("div", "flash", fxEl);
          break;
        case "polish":
          for (let i = 0; i < 5; i++) at(el("div", "star", fxEl, "\u2726"), `${rnd2(3, 92)}%`, `${rnd2(3, 85)}%`).style.animationDelay = `${rnd2(0, 0.7)}s`;
          break;
        case "search":
          el("div", "scan", fxEl);
          break;
        default:
          el("div", "gear", fxEl, "\u2699");
      }
    }
    const COVERED = /^(remove|erase|paint|spray|polish|font|write|build|measure|dance|photo|tinker)$/;
    const GROWS = { font: 24, write: 24, measure: 48, build: 48, polish: 16, dance: 16, photo: 16 };
    function play(c, msg) {
      c.queue = c.queue.filter((st) => !st.guess);
      if (c.cur && c.cur.guess) c.cur.endAt = 0;
      c.leaving = false;
      c.endAfterQueue = null;
      c.dismissed = false;
      const ghosts = [];
      for (const st of msg.steps || []) {
        const s = { ...st, id: ++stepSeq };
        if (COVERED.test(s.kind)) {
          s.el = resolve(s);
          if (s.el) {
            const r = s.el.getBoundingClientRect();
            s.rect = r;
            const { w, h } = vp();
            const pad = GROWS[s.kind] ? Math.round(GROWS[s.kind] + Math.min(r.width, r.height) * 0.3) : 0;
            const crop = {
              left: Math.max(0, r.left - pad),
              top: Math.max(0, r.top - pad),
              width: Math.min(r.right + pad, w) - Math.max(0, r.left - pad),
              height: Math.min(r.bottom + pad, h) - Math.max(0, r.top - pad)
            };
            if (crop.width > 2 && crop.height > 2 && crop.width * crop.height < w * h * 0.6) {
              s.crop = crop;
              s.cropOff = { x: crop.left - r.left, y: crop.top - r.top };
              ghosts.push({ step: s.id, rect: crop });
            }
          }
        }
        c.queue.push(s);
      }
      return { ghosts, dpr: window.devicePixelRatio || 1 };
    }
    function attachGhosts(c, msg) {
      const now = performance.now();
      for (const g of msg.ghosts || []) {
        const st = [c.cur, ...c.queue].find((x) => x && x.id === g.step);
        if (st && g.src && !st.revealing) {
          st.coverSrc = g.src;
          showCover(c, st, now);
        }
      }
    }
    function guess(c, a) {
      const busyWithClaude = c.cur && !c.cur.guess && c.cur.kind !== "idle" || c.queue.some((s2) => !s2.guess);
      const s = {
        kind: a.kind,
        say: a.label || "",
        ms: GUESS_MS,
        color: a.color,
        measure: a.measure,
        selectors: a.selectors,
        components: a.components,
        pattern: a.pattern,
        sign: a.sign,
        guess: true,
        id: ++stepSeq,
        toolId: a.toolId,
        task: a.task
      };
      if (a.hold && a.toolId && !(performance.now() - (ended.get(a.toolId) || -1e9) < 3e4)) {
        s.hold = true;
        s.ms = HOLD_MS;
      }
      if (a.kind === "wave") {
        const sign = c.svg.querySelector(".cw-p-ask text");
        if (sign) sign.textContent = a.sign || "!?";
        s.ms = 6e5;
        const resume = c.cur && c.cur.hold ? [{ ...c.cur, arrivedAt: 0, endAt: 0, dozing: false, sit: null }] : [];
        c.queue = [s, ...resume, ...c.queue.filter((x) => x.kind !== "wave")];
        if (c.cur) {
          c.cur.hold = false;
          c.cur.endAt = 0;
        }
        c.leaving = false;
        c.endAfterQueue = null;
        return;
      }
      if (busyWithClaude) return;
      c.leaving = false;
      c.endAfterQueue = null;
      const now = performance.now();
      for (const st of [c.cur, ...c.queue]) if (st && st.guess) release(c, st, now);
      c.queue = c.queue.filter((x) => !x.guess || x.react);
      c.queue.push(s);
    }
    function finish(c, ok) {
      const now = performance.now();
      for (const st of [c.cur, ...c.queue]) release(c, st, now);
      c.queue = c.queue.filter((x) => x.kind !== "wave");
      if (c.cur && c.cur.kind === "wave") c.cur.endAt = 0;
      c.queue.push({ kind: ok ? "done" : "error", say: MOOD_LABEL[ok ? "done" : "error"], ms: ok ? 3e3 : 4e3, id: ++stepSeq, target: {} });
      c.endAfterQueue = true;
    }
    let peekTimer = 0;
    let peeked = [];
    function peek(rects) {
      unpeek();
      if (!layer || !Array.isArray(rects) || !rects.length) return;
      const pad = 2;
      for (const n of layer.children) {
        if (n.classList.contains("cover")) continue;
        const own = n.getBoundingClientRect();
        const boxes = [own, ...[...n.querySelectorAll(".label, .tag")].map((x) => x.getBoundingClientRect())].filter((b) => b.width && b.height);
        const hits = rects.filter((r) => boxes.some((b) => r.left - pad < b.right && r.left + r.width + pad > b.left && r.top - pad < b.bottom && r.top + r.height + pad > b.top));
        if (!hits.length) continue;
        const holes = hits.map((r) => {
          const w = r.width + pad * 2;
          const h = r.height + pad * 2;
          return `M${r.left - own.left - pad} ${r.top - own.top - pad}h${w}v${h}h${-w}Z`;
        }).join("");
        n.style.clipPath = `path(evenodd, "M-9999 -9999H9999V9999H-9999Z${holes}")`;
        peeked.push(n);
      }
      if (peeked.length) peekTimer = setTimeout(unpeek, 1500);
    }
    function unpeek() {
      clearTimeout(peekTimer);
      for (const n of peeked) n.style.removeProperty("clip-path");
      peeked = [];
    }
    window.__cmClawd = (msg) => {
      if (!msg || msg.op === "hide") return hideAll();
      if (msg.op === "peek") {
        if (msg.on) peek(msg.rects);
        else unpeek();
        return null;
      }
      const id = String(msg.id || "job");
      if (msg.op === "leave") {
        const c2 = clawds.get(id);
        if (c2) c2.endAfterQueue = true;
        if (c2 && !c2.cur && !c2.queue.length) c2.leaving = true;
        return null;
      }
      if (msg.op === "ghosts") {
        const c2 = clawds.get(id);
        if (c2) attachGhosts(c2, msg);
        return null;
      }
      if (msg.op === "end") {
        const c2 = clawds.get(id);
        if (c2) endTool(c2, msg);
        else ended.set(msg.toolId, performance.now());
        return null;
      }
      if (msg.op === "helper" && !msg.on && !clawds.has(id)) return null;
      ensureLayer();
      const c = getClawd(id, msg);
      if (msg.op === "play") return play(c, msg);
      if (msg.op === "helper") {
        helper(c, msg);
        return null;
      }
      if (msg.op === "act") guess(c, msg);
      else if (msg.op === "done") finish(c, true);
      else if (msg.op === "error") finish(c, false);
      return null;
    };
  }
  if (!window.__cmClawd) install();
})();
