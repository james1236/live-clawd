(() => {
  // extension/src/api.js
  var api = globalThis.browser || globalThis.chrome;
  var FIREFOX = typeof globalThis.browser !== "undefined" && !!globalThis.browser.runtime.getBrowserInfo;

  // extension/src/clawd-actions.js
  var KINDS = [
    ["hack", /\b(fetch\s*\(|XMLHttpRequest|WebSocket|GM_xmlhttpRequest|GM\.xmlHttpRequest|sendBeacon|EventSource)/g],
    ["stash", /\b(localStorage|sessionStorage|GM_setValue|GM_getValue|GM\.setValue|GM\.getValue|indexedDB|document\.cookie)/g],
    ["remove", /(\.remove\(\)|removeChild\(|replaceChildren\(\))/g],
    ["erase", /(display\s*[:=]\s*['"]?none|visibility\s*[:=]\s*['"]?hidden|opacity\s*[:=]\s*['"]?0(?![.\d])|\.hidden\s*=\s*true)/gi],
    ["add", /(createElement\(|insertAdjacent(HTML|Element)\(|appendChild\(|\.append\(|\.prepend\(|\.before\(|\.after\(|innerHTML\s*\+=)/g],
    ["photo", /(<img|\.src\s*=|background-image\s*:\s*url|createElement\(\s*['"]img|\bcanvas\b)/gi],
    ["dance", /(animation|transition|@keyframes|transform\s*:)/gi],
    ["watch", /\b(MutationObserver|IntersectionObserver|ResizeObserver|setInterval|requestAnimationFrame)/g],
    ["wire", /(addEventListener\(|\bon(click|key\w+|input|change|submit|scroll)\s*=|\bon[A-Z]\w*=\{|\.click\(\))/g],
    ["spray", /(linear-gradient|radial-gradient|conic-gradient|filter\s*:|backdrop-filter|mix-blend-mode)/gi],
    ["paint", /((^|[^-\w])(color|background(-color)?|backgroundColor|bgcolor|fill|stroke|accent-color|caret-color)\s*:|border(-\w+)?-color\s*:|border\w*Color\s*:|\.style\.(color|background\w*)\s*=|palette\.)/g],
    ["font", /(font(-\w+)?\s*:|font[A-Z]\w*\s*:|line-?[hH]eight\s*:|letter-?[sS]pacing\s*:|text-?[tT]ransform\s*:|text-decoration\s*:|typography|variant=["']h\d|\.style\.font\w*\s*=)/g],
    ["measure", /((^|[^-\w])((max|min)-?)?([wW]idth|[hH]eight)\s*:|\.style\.(width|height)\s*=)/g],
    ["polish", /(border(-?[rR]adius)?\s*:|box-?[sS]hadow\s*:|outline\s*:|text-?[sS]hadow\s*:|elevation=)/g],
    ["build", /((^|[^-\w])(display|position|margin\w*|padding\w*|gap|flex\w*|grid\w*|float|align-?\w+|justify-?\w+|z-?[iI]ndex|top|left|right|bottom|overflow|[mp][xytblr]?)\s*:|<(Box|Stack|Grid|Container)\b)/g],
    ["write", /(textContent\s*=|innerText\s*=|\.title\s*=|placeholder|\.value\s*=|innerHTML\s*=)/g]
  ];
  var VERB = {
    think: "Thinking",
    read: "Reading the page",
    search: "Looking for",
    fetch: "Fetching",
    paint: "Painting",
    spray: "Spray-painting",
    font: "Restyling the text in",
    write: "Writing in",
    erase: "Hiding",
    remove: "Vacuuming up",
    build: "Rebuilding",
    measure: "Measuring",
    add: "Adding to",
    wire: "Wiring up",
    hack: "Hacking the network for",
    watch: "Keeping watch on",
    dance: "Choreographing",
    photo: "Photographing",
    stash: "Stashing data for",
    polish: "Polishing",
    tinker: "Tinkering with"
  };
  var NO_SEL_LABEL = {
    hack: "Hacking the network",
    stash: "Stashing data in the vault",
    add: "Building something new",
    watch: "Keeping watch over the page",
    wire: "Wiring up some behaviour"
  };
  var JS_WORDS = /^(if|else|for|while|try|catch|finally|do|switch|return|function|const|let|var|class|new|async|await|=>|\))$/;
  function looksLikeSelector(s) {
    s = s.trim();
    if (!s || s.length > 120 || JS_WORDS.test(s)) return false;
    if (/[=;'"`]|\b(function|return|const|let|var|if|else)\b|=>/.test(s)) return false;
    if (/\(/.test(s) && !/:(not|is|where|has|nth-[\w-]+)\(/.test(s)) return false;
    return /^[\w\s.#*>+~:[\]\-(),="^$|]+$/.test(s);
  }
  function cssBlocks(code) {
    const out = [];
    const re = /([^{}]*?)\{([^{}]*)\}/g;
    let m;
    while (m = re.exec(code)) {
      let head = m[1].split(/[`'"\n;]/).pop().trim();
      if (head.startsWith("@")) continue;
      head = head.replace(/^.*\*\//, "").trim();
      const sels = head.split(",").map((s) => s.trim()).filter(looksLikeSelector);
      if (sels.length && /:\s*[^;]+/.test(m[2])) out.push({ sels, decls: m[2] });
    }
    return out;
  }
  function jsSelectors(code) {
    const out = [];
    let m;
    const q = /querySelector(?:All)?\(\s*(['"`])((?:(?!\1).){1,160})\1/g;
    while (m = q.exec(code)) if (!/\$\{/.test(m[2])) out.push(m[2]);
    const id = /getElementById\(\s*['"`]([\w-]+)/g;
    while (m = id.exec(code)) out.push(`#${m[1]}`);
    const cls = /getElementsByClassName\(\s*['"`]([\w-]+)/g;
    while (m = cls.exec(code)) out.push(`.${m[1]}`);
    const tag = /getElementsByTagName\(\s*['"`]([\w-]+)/g;
    while (m = tag.exec(code)) out.push(m[1]);
    return out;
  }
  function pickKind(code) {
    let best = null;
    let bestN = 0;
    for (const [kind, re] of KINDS) {
      const n = (code.match(re) || []).length;
      if (n > bestN) {
        best = kind;
        bestN = n;
      }
    }
    return best || "tinker";
  }
  var COLOR_RE = /(?:^|[^-\w])(?:color|background(?:-color)?|fill|border(?:-\w+)?-color)\s*:\s*(#[0-9a-f]{3,8}\b|(?:rgb|hsl)a?\([^)]*\)|[a-z]{3,20})/i;
  var MEASURE_RE = /(?:^|[^-\w])((?:max-|min-)?(?:width|height))\s*:\s*([^;!}\n]{1,24})/i;
  function shortSel(sel) {
    if (!sel) return "the page";
    const s = sel.replace(/\s+/g, " ").trim();
    return s.length > 30 ? `${s.slice(0, 29)}\u2026` : s;
  }
  var BASH_KINDS = [
    [/\b(vitest|jest|pytest|mocha|playwright|cypress|(npm|pnpm|yarn|bun)( run)? test|cargo test|go test|make test|check)\b/, "test", "Running the tests", "test"],
    [/\b(eslint|prettier|lint|ruff|clippy|stylelint|black|biome)\b/, "polish", "Linting and tidying", "lint"],
    [/\b(tsc|build|make|cargo build|go build|webpack|vite build|gulp|compile|cmake|ninja)\b/, "compile", "Building the project", "build"],
    [/\b(npm (i|install|add)|pnpm (i|install|add)|yarn add|pip install|cargo add|apt|brew)\b/, "install", "Installing packages", "install"],
    [/\bgit (commit|add|stash)\b/, "stash", "Committing to git"],
    [/\bgit (push|pull|fetch|clone)\b/, "mail", "Syncing with the remote", "sync"],
    [/\bgit\b/, "read", "Checking git"],
    [/\b(curl|wget|http)\b/, "fetch", "Fetching from the web"],
    [/\b(ls|cat|head|tail|grep|rg|find|fd|tree|wc|less)\b/, "search", "Poking around the files"],
    [/\b(rm|mv|cp|mkdir)\b/, "tinker", "Shuffling files around"]
  ];
  var UI_EXT = /\.(tsx|jsx|vue|svelte|astro|html?)$/i;
  var STYLE_EXT = /\.(css|scss|sass|less|styl)$/i;
  function sourceTargets(code, file) {
    const sels = [];
    const comps = [];
    let m;
    const cls = /className\s*=\s*["'`{]?\s*["'`]([\w\s-]+)["'`]/g;
    while (m = cls.exec(code)) sels.push(`.${m[1].trim().split(/\s+/)[0]}`);
    const id = /\bid\s*=\s*["'`{]?\s*["'`]([\w-]+)["'`]/g;
    while (m = id.exec(code)) sels.push(`#${m[1]}`);
    const tid = /data-testid\s*=\s*["'`{]?\s*["'`]([\w-]+)["'`]/g;
    while (m = tid.exec(code)) sels.push(`[data-testid="${m[1]}"]`);
    const fn = /\b(?:function|const|let|class)\s+([A-Z]\w+)/g;
    while (m = fn.exec(code)) comps.push(m[1]);
    const base = (file || "").split("/").pop().replace(/\.\w+$/, "");
    if (/^[A-Z]\w+$/.test(base)) comps.unshift(base);
    else if (base === "index") {
      const dir = (file || "").split("/").slice(-2, -1)[0] || "";
      if (/^[A-Z]\w+$/.test(dir)) comps.unshift(dir);
    }
    return { sels: [...new Set(sels)].filter(looksLikeSelector), comps: [...new Set(comps)].slice(0, 8) };
  }
  var fileName = (f) => (f || "").split("/").pop();
  function classifySource(name, detail, file) {
    const short = fileName(file);
    if (name === "Bash") {
      const hit = BASH_KINDS.find(([re]) => re.test(detail));
      return {
        kind: hit ? hit[1] : "hack",
        selectors: [],
        task: hit && hit[3],
        label: hit ? hit[2] : `Running ${detail.split(/\s+/)[0] || "a command"}`
      };
    }
    if (name === "Read" || name === "NotebookRead") return { kind: "read", selectors: [], label: `Reading ${short || "a file"}` };
    if (name === "Grep" || name === "Glob") return { kind: "search", selectors: [], pattern: name === "Grep" ? detail : "", label: `Searching for \u201C${detail.slice(0, 24)}\u201D` };
    if (name === "WebFetch" || name === "WebSearch") return { kind: "fetch", selectors: [], label: "Browsing the web" };
    if (name === "Task" || name === "Agent") return { kind: "think", selectors: [], label: "Briefing a helper" };
    if (name === "TodoWrite") return { kind: "write", selectors: [], label: "Updating the to-do list" };
    if (!/^(Edit|Write|MultiEdit|NotebookEdit)$/.test(name)) return { kind: "think", selectors: [], label: `${VERB.think}\u2026` };
    if (/\.(md|mdx|txt|rst)$/i.test(short)) return { kind: "write", selectors: [], label: `Writing ${short}` };
    if (/\.(test|spec)\.\w+$|(^|\/)(tests?|__tests__)\//.test(file || "")) return { kind: "search", selectors: [], label: `Writing tests in ${short}` };
    if (/\.(json|ya?ml|toml|ini|env|lock)$|config\./i.test(short)) return { kind: "tinker", selectors: [], label: `Tweaking ${short}` };
    const isStyle = STYLE_EXT.test(short);
    const isUi = UI_EXT.test(short) || /styled|sx=|css`|className/.test(detail);
    if (!isStyle && !isUi) {
      const kind = pickKind(detail);
      return { kind: kind === "tinker" ? "hack" : kind, selectors: [], label: `Editing ${short || "code"}` };
    }
    const action2 = classifyCode(detail);
    if (isUi) {
      const t = sourceTargets(detail, file);
      action2.selectors = [.../* @__PURE__ */ new Set([...action2.selectors, ...t.sels])].slice(0, 12);
      action2.components = t.comps;
    }
    const who = action2.components && action2.components[0] ? `<${action2.components[0]}>` : shortSel(action2.selectors[0]) || short;
    action2.label = `${VERB[action2.kind]} ${who === "the page" ? short : who}`;
    return action2;
  }
  function jsxTags(text) {
    text = String(text);
    const used = [...new Set([...text.matchAll(/(?:^|[\s({,]|return\s)<([A-Z]\w*)(?=[\s/>])/gm)].map((m) => m[1]))];
    const defined = [...new Set([...text.matchAll(/\b(?:function|const|let|class)\s+([A-Z]\w*)/g)].map((m) => m[1]))].filter((n) => used.includes(n) || /^\s*(export\s+)?(default\s+)?function\s/m.test(text));
    return defined.length ? defined.filter((n) => !/Props$|Type$/.test(n)) : used;
  }
  function classifyChange({ file, added = "", removed = "" }) {
    const short = fileName(file);
    const addTags = jsxTags(added);
    const delTags = jsxTags(removed);
    const base = classifySource("Edit", added || removed, file);
    const fileComps = base.components || [];
    if (delTags.length && !addTags.length && removed.length > added.length) {
      return { ...base, kind: "remove", components: [...delTags, ...fileComps], label: `Vacuuming up <${delTags[0]}>` };
    }
    if (addTags.length && !delTags.length && added.length > removed.length) {
      return { ...base, kind: "add", components: [...addTags, ...fileComps], label: `Adding <${addTags[0]}>` };
    }
    if (!added.trim() && removed.trim()) {
      return { ...base, kind: "erase", components: fileComps, label: `Trimming ${short}` };
    }
    return base;
  }
  function classifyTool(name, detail = "", file = "") {
    detail = String(detail || "");
    if (file || name === "Bash" && !/^curl\b/.test(detail)) return classifySource(name, detail, file);
    if (name === "Grep") {
      return { kind: "search", selectors: [], pattern: detail.slice(0, 200), label: `${VERB.search} \u201C${detail.slice(0, 28)}\u201D` };
    }
    if (name === "Read" || name === "Glob") {
      if (/screenshot/.test(detail)) return { kind: "photo", selectors: [], label: "Looking at a screenshot" };
      return { kind: "read", selectors: [], label: VERB.read };
    }
    if (name === "Bash") return { kind: "fetch", selectors: [], label: "Fetching something from the web" };
    if (name !== "Edit" && name !== "Write" && name !== "MultiEdit") {
      return { kind: "think", selectors: [], label: `${VERB.think}\u2026` };
    }
    return classifyCode(detail);
  }
  function classifyCode(detail) {
    const kind = pickKind(detail);
    const blocks = cssBlocks(detail);
    const kindRe = KINDS.find(([k]) => k === kind)?.[1];
    const matching = kindRe ? blocks.filter((b) => (kindRe.lastIndex = 0, kindRe.test(b.decls))) : [];
    const selectors = [.../* @__PURE__ */ new Set([
      ...matching.flatMap((b) => b.sels),
      ...jsSelectors(detail),
      ...blocks.flatMap((b) => b.sels)
    ])].slice(0, 12);
    const action2 = { kind, selectors, label: `${VERB[kind]} ${shortSel(selectors[0])}` };
    if (!selectors.length && NO_SEL_LABEL[kind]) action2.label = NO_SEL_LABEL[kind];
    if (kind === "paint" || kind === "spray") {
      const src = matching.map((b) => b.decls).join(";") || detail;
      const m = src.match(COLOR_RE);
      if (m && !/^(inherit|initial|unset|none|transparent|var|currentcolor|important)$/i.test(m[1])) action2.color = m[1];
    }
    if (kind === "measure") {
      const m = (matching.map((b) => b.decls).join(";") || detail).match(MEASURE_RE);
      if (m) action2.measure = `${m[1]}: ${m[2].trim()}`;
    }
    return action2;
  }
  var MOOD_LABEL = {
    idle: "Ready when you are",
    think: "Thinking\u2026",
    done: "All done!",
    error: "Oops, that didn\u2019t work",
    wave: "Need you in the terminal",
    water: "Hydrating\u2026 AI is thirsty work",
    ponder: "Thinking it through",
    compact: "Compacting my memory",
    background: "Left it running in the background"
  };

  // extension/src/clawd-sound.js
  var ctx = null;
  var master = null;
  var noiseBuf = null;
  function audio() {
    if (!ctx) {
      ctx = new AudioContext();
      master = ctx.createGain();
      master.connect(ctx.destination);
      noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    if (ctx.state === "suspended") ctx.resume();
    return ctx;
  }
  function tone(f, dur, { type = "square", vol = 0.3, to = null, at = 0, vibrato = 0 } = {}) {
    const t = ctx.currentTime + at;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t + dur);
    if (vibrato) {
      const lfo = ctx.createOscillator();
      const lg = ctx.createGain();
      lfo.frequency.value = 6;
      lg.gain.value = vibrato;
      lfo.connect(lg).connect(o.frequency);
      lfo.start(t);
      lfo.stop(t + dur);
    }
    g.gain.setValueAtTime(1e-4, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 8e-3);
    g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
    o.connect(g).connect(master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
  function noise(dur, { vol = 0.25, freq = 1500, to = null, kind = "bandpass", q = 1, at = 0 } = {}) {
    const t = ctx.currentTime + at;
    const s = ctx.createBufferSource();
    s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter();
    f.type = kind;
    f.Q.value = q;
    f.frequency.setValueAtTime(freq, t);
    if (to) f.frequency.exponentialRampToValueAtTime(to, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(1e-4, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(1e-4, t + dur);
    s.connect(f).connect(g).connect(master);
    s.start(t, Math.random() * 0.5);
    s.stop(t + dur + 0.02);
  }
  var rnd = (a, b) => a + Math.random() * (b - a);
  var PENTA = [523, 587, 659, 784, 880, 1047];
  var note = 0;
  var SOUNDS = {
    step: () => tone(rnd(170, 230), 0.045, { type: "triangle", vol: 0.22 }),
    glug: () => tone(rnd(300, 360), 0.11, { type: "sine", vol: 0.35, to: 160 }),
    ahh: () => {
      tone(560, 0.35, { type: "sine", vol: 0.18, to: 420, vibrato: 12 });
      noise(0.3, { vol: 0.05, freq: 900 });
    },
    whoosh: () => noise(0.3, { vol: 0.25, freq: 400, to: 2600, q: 2 }),
    giggle: () => [0, 1, 2, 3, 4, 5].forEach((i) => tone(i % 2 ? 760 : 980, 0.05, { type: "square", vol: 0.12, at: i * 0.07, to: i % 2 ? 820 : 1040 })),
    pop: () => tone(520, 0.07, { type: "sine", vol: 0.35, to: 1300 }),
    boop: () => tone(480, 0.08, { type: "sine", vol: 0.25, to: 720 }),
    swish: () => noise(0.18, { vol: 0.16, freq: 2500, to: 5e3, kind: "highpass" }),
    psst: () => noise(0.22, { vol: 0.14, freq: 3500, kind: "highpass" }),
    vacuum: () => {
      noise(1.05, { vol: 0.12, freq: 500, to: 700, kind: "lowpass" });
      tone(110, 1.05, { type: "sawtooth", vol: 0.04, vibrato: 4 });
    },
    slurp: () => tone(900, 0.35, { type: "sine", vol: 0.25, to: 140 }),
    bonk: () => {
      tone(170, 0.13, { type: "sine", vol: 0.45, to: 80 });
      noise(0.03, { vol: 0.2, freq: 3200, kind: "highpass" });
    },
    squeak: () => tone(rnd(1300, 1500), 0.07, { type: "square", vol: 0.08, to: 1900 }),
    tick: () => noise(0.025, { vol: 0.18, freq: 4500, kind: "highpass" }),
    chime: () => [880, 1320, 1760].forEach((f, i) => tone(f, 0.25, { type: "sine", vol: 0.15, at: i * 0.06 })),
    zap: () => tone(1300, 0.13, { type: "sawtooth", vol: 0.1, to: 180 }),
    blip: () => tone(rnd(600, 1300), 0.035, { type: "square", vol: 0.08 }),
    note: () => tone(PENTA[note = (note + 1 + Math.floor(Math.random() * 2)) % PENTA.length], 0.14, { type: "triangle", vol: 0.22 }),
    shutter: () => {
      noise(0.035, { vol: 0.3, freq: 3e3 });
      noise(0.05, { vol: 0.25, freq: 2e3, at: 0.08 });
    },
    shimmer: () => [1568, 2093, 2637].forEach((f, i) => tone(f, 0.18, { type: "sine", vol: 0.06, at: i * 0.05 })),
    zip: () => tone(300, 0.28, { type: "square", vol: 0.06, to: 1e3 }),
    creak: () => {
      tone(140, 0.3, { type: "sawtooth", vol: 0.05, to: 210 });
      tone(988, 0.08, { type: "square", vol: 0.1, at: 0.32 });
      tone(1319, 0.25, { type: "square", vol: 0.1, at: 0.4 });
    },
    sonar: () => tone(1050, 0.5, { type: "sine", vol: 0.18 }),
    hmm: () => tone(260, 0.3, { type: "triangle", vol: 0.18, to: 235 }),
    boing: () => {
      tone(180, 0.12, { type: "sine", vol: 0.3, to: 520 });
      tone(520, 0.15, { type: "sine", vol: 0.2, to: 300, at: 0.12 });
    },
    thought: () => tone(900, 0.04, { type: "sine", vol: 0.12 }),
    flip: () => noise(0.08, { vol: 0.18, freq: 1500, to: 900 }),
    dingdong: () => {
      tone(659, 0.4, { type: "sine", vol: 0.3 });
      tone(523, 0.55, { type: "sine", vol: 0.3, at: 0.35 });
    },
    happy: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.1, { type: "square", vol: 0.12, at: i * 0.08 })),
    sad: () => [[392, 370], [370, 349], [349, 330], [330, 294]].forEach(([f, to], i) => tone(f, i === 3 ? 0.9 : 0.32, { type: "triangle", vol: 0.25, to, at: i * 0.36, vibrato: i === 3 ? 10 : 0 })),
    sniffle: () => {
      noise(0.07, { vol: 0.1, freq: 2600, q: 3 });
      noise(0.09, { vol: 0.1, freq: 2300, q: 3, at: 0.12 });
    },
    phew: () => {
      noise(0.35, { vol: 0.1, freq: 1300, to: 500 });
      tone(640, 0.25, { type: "sine", vol: 0.18, to: 420, at: 0.05 });
    },
    tape: () => tone(rnd(220, 260), 0.06, { type: "square", vol: 0.05 }),
    // long waits, results, helpers
    snore: () => {
      noise(1.1, { vol: 0.07, freq: 300, to: 520, kind: "lowpass" });
      tone(95, 1.1, { type: "sawtooth", vol: 0.03, to: 110, vibrato: 6 });
    },
    yawn: () => tone(520, 0.9, { type: "triangle", vol: 0.16, to: 230, vibrato: 8 }),
    crunch: () => [0, 0.09, 0.2, 0.27].forEach((at) => noise(0.07, { vol: 0.22, freq: rnd(700, 1400), q: 2, at })),
    ding: () => {
      tone(1568, 0.6, { type: "sine", vol: 0.2 });
      tone(2093, 0.5, { type: "sine", vol: 0.08, at: 0.01 });
    },
    scribble: () => [0, 0.07, 0.16].forEach((at) => noise(0.05, { vol: 0.1, freq: rnd(3e3, 4200), q: 4, at })),
    rustle: () => noise(0.25, { vol: 0.12, freq: 1800, to: 1100, q: 1.5 }),
    dink: () => {
      tone(2350, 0.12, { type: "sine", vol: 0.3, to: 2250 });
      tone(3520, 0.08, { type: "sine", vol: 0.12 });
      tone(5100, 0.05, { type: "sine", vol: 0.05 });
    },
    fork: () => {
      tone(260, 0.55, { type: "triangle", vol: 0.18, to: 780, vibrato: 14 });
      noise(0.3, { vol: 0.06, freq: 1200, to: 3e3, at: 0.3 });
    },
    bubble: () => [0, 0.08, 0.15].forEach((at) => tone(rnd(500, 900), 0.06, { type: "sine", vol: 0.14, to: rnd(1100, 1500), at })),
    click: () => tone(rnd(1900, 2200), 0.02, { type: "square", vol: 0.05 }),
    yes: () => {
      tone(523, 0.08, { type: "square", vol: 0.14 });
      tone(784, 0.08, { type: "square", vol: 0.14, at: 0.09 });
      tone(1047, 0.22, { type: "square", vol: 0.14, at: 0.18 });
    },
    facepalm: () => {
      noise(0.06, { vol: 0.3, freq: 900, q: 1 });
      tone(330, 0.5, { type: "triangle", vol: 0.18, to: 196, at: 0.12 });
    }
  };
  var SOUND_NAMES = Object.keys(SOUNDS);
  function playSound(name, volume = 0.35) {
    const fn = SOUNDS[name];
    if (!fn) return false;
    try {
      audio();
      master.gain.value = volume;
      fn();
      return ctx.state !== "suspended";
    } catch {
      return false;
    }
  }

  // extension/src/background.js
  var BRIDGE = "ws://127.0.0.1:47215/";
  var PROTOCOL = 1;
  var KEY = "liveClawd";
  var MIN_DWELL_MS = 1800;
  var CLAWD_ORANGE = "#d97757";
  var COLORS = [CLAWD_ORANGE, "#5b8fd9", "#4fa36b", "#a777d6", "#d9a13b", "#d0607e", "#3fa8a8", "#8a8f3c"];
  var ACTIVE_MS = 15 * 6e4;
  var ACTION_KIND = { vacuum: "remove" };
  var RECENT_MS = 9e4;
  var LOOPBACK = /^(localhost|127\.\d+\.\d+\.\d+|\[::1\])$/;
  var ALL_URLS = { origins: ["<all_urls>"] };
  var ICON = { 16: "icons/icon-16.png", 32: "icons/icon-32.png", 48: "icons/icon-48.png", 128: "icons/icon-128.png" };
  var ICON_ASLEEP = Object.fromEntries(Object.entries(ICON).map(([k, v]) => [k, v.replace(".png", "-asleep.png")]));
  var settings = { enabled: true, muted: [], sound: true, volume: 0.35, captureAsked: false };
  var ws = null;
  var retryMs = 1e3;
  var retryTimer = 0;
  var pingTimer = 0;
  var bridgeInfo = null;
  var sessions = /* @__PURE__ */ new Map();
  var lanes = /* @__PURE__ */ new Map();
  var knownPorts = /* @__PURE__ */ new Set();
  var ready = load();
  async function load() {
    try {
      settings = { ...settings, ...(await api.storage.local.get(KEY))[KEY] };
    } catch {
    }
  }
  var save = () => api.storage.local.set({ [KEY]: settings });
  function originOf(url) {
    try {
      const u = new URL(url);
      if (!/^https?:$/.test(u.protocol) || !LOOPBACK.test(u.hostname)) return null;
      return { origin: u.origin, port: +u.port || (u.protocol === "https:" ? 443 : 80) };
    } catch {
      return null;
    }
  }
  function connect() {
    clearTimeout(retryTimer);
    if (ws || !settings.enabled) return;
    try {
      ws = new WebSocket(BRIDGE);
    } catch {
      ws = null;
      scheduleRetry();
      return;
    }
    ws.onopen = () => {
      retryMs = 1e3;
      refreshIcons();
      pingTimer = setInterval(() => send({ type: "ping" }), 2e4);
    };
    ws.onmessage = (e) => {
      let msg;
      try {
        msg = JSON.parse(e.data);
      } catch {
        return;
      }
      if (msg && msg.type === "live") onEvent(msg);
      else if (msg && msg.type === "hello") bridgeInfo = { protocol: msg.protocol || 1, plugin: msg.plugin || "" };
    };
    ws.onclose = () => {
      ws = null;
      bridgeInfo = null;
      clearInterval(pingTimer);
      refreshIcons();
      scheduleRetry();
    };
  }
  function scheduleRetry() {
    if (!settings.enabled) return;
    retryTimer = setTimeout(connect, retryMs);
    retryMs = Math.min(retryMs * 2, 5e3);
  }
  function disconnect() {
    clearTimeout(retryTimer);
    if (ws) {
      try {
        ws.close();
      } catch {
      }
    }
    ws = null;
  }
  function send(obj) {
    if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
  }
  function ack(ev, status = "") {
    if (ev.ackId) send({ type: "ack", ackId: ev.ackId, status });
  }
  var recent = /* @__PURE__ */ new Map();
  var many = false;
  async function manyAtOnce() {
    const now = Date.now();
    const open = /* @__PURE__ */ new Set();
    for (const t of await api.tabs.query({}).catch(() => [])) {
      const o = originOf(t.url);
      if (o) open.add(o.port);
    }
    const pages = /* @__PURE__ */ new Set();
    for (const [session, s] of [...recent]) {
      if (now - s.at > ACTIVE_MS) {
        recent.delete(session);
        continue;
      }
      const mine = s.ports.filter((p) => open.has(p)).sort().join(",");
      if (mine) pages.add(mine);
    }
    return pages.size > 1;
  }
  function colorFor(win, session) {
    if (!many) return CLAWD_ORANGE;
    if (/^\d+$/.test(win || "")) return COLORS[+win % COLORS.length];
    let h = 0;
    for (const ch of String(session)) h = h * 31 + ch.charCodeAt(0) | 0;
    return COLORS[Math.abs(h) % COLORS.length];
  }
  function toOverlay(ev) {
    const [win] = String(ev.tmux || "").trim().split(/\s+/);
    const base = {
      id: `live:${ev.session}`,
      color: colorFor(win, ev.session),
      live: true
    };
    if (ev.sub) {
      const a = ev.event === "PreToolUse" ? classifyTool(ev.tool, ev.detail, ev.file || "") : { kind: "idle" };
      return { ...base, op: "helper", agentId: ev.agentId, kind: a.kind };
    }
    switch (ev.event) {
      case "Clawd":
        return {
          ...base,
          op: "play",
          steps: (ev.steps || []).map((st) => ({
            target: st.target || {},
            kind: ACTION_KIND[st.action] || st.action || "tinker",
            say: String(st.say || "").slice(0, 80),
            color: st.color,
            ms: Math.max(1e3, Math.min(6e3, st.ms | 0 || 2600))
          }))
        };
      case "PostToolUse":
        return [
          { ...base, op: "end", toolId: ev.toolId, ok: !!ev.ok, interrupted: !!ev.interrupted },
          ev.changes && ev.changes.length && { ...base, op: "act", ...classifyChange(ev.changes[0]) }
        ].filter(Boolean);
      case "UserPromptSubmit":
        return {
          ...base,
          op: "act",
          kind: "think",
          selectors: [],
          hold: true,
          toolId: "prompt",
          label: ev.message ? `On it: \u201C${ev.message}\u201D` : "New request!"
        };
      case "PreToolUse": {
        if (ev.bg) return { ...base, op: "act", kind: "timer", selectors: [], label: MOOD_LABEL.background };
        const a = classifyTool(ev.tool, ev.detail, ev.file || "");
        if (ev.say && ["think", "read", "tinker", "hack"].includes(a.kind)) a.label = ev.say;
        return { ...base, op: "act", ...a, toolId: ev.toolId, hold: !!ev.toolId };
      }
      case "SubagentStart":
      case "SubagentStop":
        return { ...base, op: "helper", on: ev.event === "SubagentStart", agentId: ev.agentId, label: ev.agentType };
      case "PreCompact":
        return { ...base, op: "act", kind: "compact", selectors: [], label: MOOD_LABEL.compact, hold: true, toolId: "compact" };
      case "PostCompact":
        return { ...base, op: "end", toolId: "compact", ok: true };
      case "Notification":
        return {
          ...base,
          op: "act",
          kind: "wave",
          selectors: [],
          sign: win ? `#${win}` : "!?",
          label: ev.message || MOOD_LABEL.wave
        };
      case "Stop":
        return { ...base, op: "done" };
      case "SessionEnd":
        return { ...base, op: "leave" };
      default:
        return null;
    }
  }
  async function targetTabs(ports) {
    const tabs = await api.tabs.query({ active: true });
    return tabs.filter((t) => {
      const o = originOf(t.url);
      return o && ports.includes(o.port) && !settings.muted.includes(o.origin);
    });
  }
  async function onEvent(ev) {
    await ready;
    if (ev.event === "SessionEnd") recent.delete(ev.session);
    else recent.set(ev.session, { ports: ev.ports || [], at: Date.now() });
    many = await manyAtOnce();
    if (ev.ports && ev.ports.some((p) => !knownPorts.has(p))) {
      ev.ports.forEach((p) => knownPorts.add(p));
      refreshIcons();
    }
    const out = toOverlay(ev);
    if (!out) {
      ack(ev);
      return;
    }
    for (const m of [].concat(out)) await onMessage(ev, m);
  }
  async function onMessage(ev, msg) {
    const st = sessions.get(ev.session);
    if (msg.op === "end" || msg.op === "helper") {
      if (msg.op === "end" && st && st.last && st.last.toolId === msg.toolId) st.last = { ...st.last, hold: false };
      for (const t of await targetTabs(ev.ports)) clawdNow(t.id, msg);
      return;
    }
    if (msg.op === "play") {
      const total = msg.steps.reduce((t, x) => t + x.ms, 0);
      if (st) st.choreoUntil = Date.now() + total + 4e3;
      else sessions.set(ev.session, { ports: ev.ports, last: null, at: Date.now(), choreoUntil: Date.now() + total + 4e3 });
      await play(ev, msg);
      return;
    }
    if (msg.op === "act" && msg.kind !== "wave" && st && st.choreoUntil > Date.now()) return;
    if (msg.op === "leave") sessions.delete(ev.session);
    else sessions.set(ev.session, { ...st, ports: ev.ports, last: msg.op === "act" ? msg : null, at: Date.now() });
    for (const t of await targetTabs(ev.ports)) deliver(t.id, msg);
  }
  function deliver(tabId, msg) {
    const key = `${tabId}|${msg.id}`;
    let lane = lanes.get(key);
    if (!lane) lanes.set(key, lane = { at: 0, timer: 0, pending: [] });
    if (msg.op === "act" && msg.kind !== "wave") lane.pending = lane.pending.filter((m) => m.op !== "act" || m.kind === "wave");
    lane.pending.push(msg);
    const pump = () => {
      lane.timer = 0;
      const next = lane.pending.shift();
      if (!next) return;
      lane.at = Date.now();
      clawdNow(tabId, next);
      if (lane.pending.length) lane.timer = setTimeout(pump, MIN_DWELL_MS);
    };
    if (!lane.timer) {
      const wait = lane.at + MIN_DWELL_MS - Date.now();
      if (wait > 0) lane.timer = setTimeout(pump, wait);
      else pump();
    }
  }
  async function play(ev, msg) {
    let tabs = [];
    try {
      tabs = await targetTabs(ev.ports);
      const canCapture = await api.permissions.contains(ALL_URLS).catch(() => false);
      for (const t of tabs) {
        const res = await clawdNow(t.id, msg);
        if (!canCapture || !res || !res.ghosts || !res.ghosts.length) continue;
        try {
          const rects = res.ghosts.map((g) => g.rect);
          await clawdNow(t.id, { op: "peek", on: true, rects });
          await api.scripting.executeScript({
            target: { tabId: t.id },
            func: () => new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(() => r(1))))
          }).catch(() => {
          });
          let imgs;
          try {
            imgs = await cropVisible(t.windowId, rects, res.dpr);
          } finally {
            clawdNow(t.id, { op: "peek", on: false });
          }
          clawdNow(t.id, { op: "ghosts", id: msg.id, ghosts: res.ghosts.map((g, i) => ({ ...g, src: imgs[i] })) });
        } catch {
        }
      }
    } finally {
      ack(ev, tabs.length ? "" : "no-tab");
    }
  }
  async function clawdNow(tabId, msg) {
    try {
      const target = { tabId };
      if (!FIREFOX) await api.scripting.executeScript({ target, files: ["probe.js"], world: "MAIN" });
      await api.scripting.executeScript({ target, files: ["overlay.js"] });
      const [res] = await api.scripting.executeScript({
        target,
        func: (m) => window.__cmClawd ? window.__cmClawd(m) || null : null,
        args: [msg]
      });
      return res ? res.result : null;
    } catch {
      return null;
    }
  }
  async function cropVisible(windowId, rects, dpr = 1) {
    const shot = await api.tabs.captureVisibleTab(windowId, { format: "png" });
    const bmp = await createImageBitmap(await (await fetch(shot)).blob());
    return Promise.all(rects.map(async (r) => {
      try {
        const w = Math.max(1, Math.round(r.width * dpr));
        const h = Math.max(1, Math.round(r.height * dpr));
        const canvas = new OffscreenCanvas(w, h);
        canvas.getContext("2d").drawImage(bmp, Math.round(r.left * dpr), Math.round(r.top * dpr), w, h, 0, 0, w, h);
        const bytes = new Uint8Array(await (await canvas.convertToBlob({ type: "image/png" })).arrayBuffer());
        let bin = "";
        for (let i = 0; i < bytes.length; i += 32768) bin += String.fromCharCode(...bytes.subarray(i, i + 32768));
        return `data:image/png;base64,${btoa(bin)}`;
      } catch {
        return "";
      }
    }));
  }
  async function replay(tab) {
    await ready;
    if (!settings.enabled || !tab || !tab.active) return;
    const o = originOf(tab.url);
    if (!o || settings.muted.includes(o.origin)) return;
    for (const s of [...sessions.values()]) {
      if (s.last && Date.now() - s.at < RECENT_MS && s.ports.includes(o.port)) deliver(tab.id, s.last);
    }
  }
  api.tabs.onActivated.addListener(async ({ tabId }) => {
    try {
      replay(await api.tabs.get(tabId));
    } catch {
    }
  });
  api.tabs.onUpdated.addListener((tabId, info, tab) => {
    if (info.status === "complete") replay(tab);
    if (info.url || info.status === "complete") setIcon(tab);
  });
  var action = api.action || api.browserAction;
  function inactiveReason(url) {
    const o = originOf(url);
    if (!settings.enabled) return "Turned off";
    if (!o) return "Not a localhost dev page";
    if (!ws || ws.readyState !== 1) return "Waiting for Claude Code";
    if (settings.muted.includes(o.origin)) return "Muted on this site";
    if (!knownPorts.has(o.port)) return "No Claude session is working on this dev server";
    return "";
  }
  function setIcon(tab) {
    if (!tab || tab.id == null) return;
    const why = inactiveReason(tab.url);
    action.setIcon({ tabId: tab.id, path: why ? ICON_ASLEEP : ICON }).catch(() => {
    });
    action.setTitle({ tabId: tab.id, title: why ? `Live Clawd: ${why.toLowerCase()}` : "Live Clawd: on this page" }).catch(() => {
    });
  }
  async function refreshIcons() {
    await ready;
    for (const t of await api.tabs.query({}).catch(() => [])) setIcon(t);
  }
  api.tabs.onRemoved.addListener((tabId) => {
    for (const key of [...lanes.keys()]) if (key.startsWith(`${tabId}|`)) lanes.delete(key);
  });
  var lastPlayed = /* @__PURE__ */ new Map();
  var offscreen = null;
  async function sound(name) {
    const now = Date.now();
    if (now - (lastPlayed.get(name) || 0) < 45) return;
    lastPlayed.set(name, now);
    if (FIREFOX) {
      playSound(name, settings.volume);
      return;
    }
    offscreen = offscreen || api.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Clawd's sound effects"
    }).catch(() => {
    });
    await offscreen;
    api.runtime.sendMessage({ cmd: "OffscreenSound", data: { name, volume: settings.volume } }).catch(() => {
    });
  }
  async function setEnabled(enabled) {
    settings.enabled = !!enabled;
    await save();
    refreshIcons();
    if (settings.enabled) {
      retryMs = 1e3;
      connect();
    } else {
      disconnect();
      for (const t of await api.tabs.query({})) if (originOf(t.url)) clawdNow(t.id, { op: "hide", final: true });
    }
  }
  var commands = {
    /** From the overlay: one of Clawd's sounds (only for the tab you're looking at). */
    ClawdSound({ name } = {}, src) {
      if (!settings.sound || src && src.tab && !src.tab.active) return;
      sound(String(name));
    },
    /** From the overlay: a Clawd left the page (dismissed = clicked away while waving). */
    ClawdGone({ id, dismissed } = {}, src) {
      if (!dismissed || !String(id).startsWith("live:")) return;
      const s = sessions.get(String(id).slice(5));
      if (s && s.last && s.last.kind === "wave") s.last = null;
      const lane = lanes.get(`${src && src.tab && src.tab.id}|${id}`);
      if (lane) lane.pending = [];
    },
    /** For the popup: settings, the connection, and whether `url` is a muted dev page. */
    async LiveGet({ url } = {}) {
      await ready;
      const o = originOf(url);
      return {
        enabled: settings.enabled,
        sound: settings.sound,
        connected: !!ws && ws.readyState === 1,
        local: !!o,
        muted: !!o && settings.muted.includes(o.origin),
        capture: await api.permissions.contains(ALL_URLS).catch(() => false),
        // Plugin and extension out of step: which one needs updating.
        outdated: !bridgeInfo || bridgeInfo.protocol === PROTOCOL ? "" : bridgeInfo.protocol > PROTOCOL ? "extension" : "plugin",
        plugin: bridgeInfo ? bridgeInfo.plugin : "",
        version: api.runtime.getManifest().version
      };
    },
    async LiveSet({ enabled, sound: soundOn, url, muted } = {}) {
      await ready;
      if (enabled != null) await setEnabled(enabled);
      if (soundOn != null) {
        settings.sound = !!soundOn;
        await save();
        if (soundOn) sound("boop");
      }
      const o = originOf(url);
      if (o && muted != null) {
        settings.muted = settings.muted.filter((x) => x !== o.origin);
        if (muted) settings.muted.push(o.origin);
        await save();
        refreshIcons();
      }
    }
  };
  api.runtime.onMessage.addListener((msg, sender, respond) => {
    const fn = msg && commands[msg.cmd];
    if (!fn) return void 0;
    Promise.resolve(fn(msg.data, sender)).then(respond, () => respond(null));
    return true;
  });
  async function updateBadge() {
    await ready;
    const has = await api.permissions.contains(ALL_URLS).catch(() => false);
    const ask = !has && !settings.captureAsked;
    action.setBadgeText({ text: ask ? "!" : "" }).catch(() => {
    });
    if (ask) action.setBadgeBackgroundColor({ color: CLAWD_ORANGE }).catch(() => {
    });
  }
  commands.CaptureAsked = async () => {
    settings.captureAsked = true;
    await save();
    updateBadge();
  };
  api.runtime.onInstalled.addListener(async ({ reason }) => {
    if (reason !== "install") return;
    if (!await api.permissions.contains(ALL_URLS).catch(() => false)) api.tabs.create({ url: "welcome.html" });
  });
  api.permissions.onAdded?.addListener(updateBadge);
  api.permissions.onRemoved?.addListener(updateBadge);
  api.commands?.onCommand.addListener((cmd) => {
    if (cmd === "toggle-live") setEnabled(!settings.enabled);
  });
  ready.then(() => {
    connect();
    refreshIcons();
    updateBadge();
  });
})();
