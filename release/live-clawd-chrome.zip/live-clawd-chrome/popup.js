(() => {
  // extension/src/api.js
  var api = globalThis.browser || globalThis.chrome;
  var FIREFOX = typeof globalThis.browser !== "undefined" && !!globalThis.browser.runtime.getBrowserInfo;

  // extension/src/popup.js
  var $ = (id) => document.getElementById(id);
  var ask = (cmd, data) => api.runtime.sendMessage({ cmd, data });
  var url = "";
  async function render() {
    const st = await ask("LiveGet", { url });
    $("enabled").checked = st.enabled;
    $("sound").checked = st.sound;
    $("muteRow").hidden = !st.local;
    $("muted").checked = st.muted;
    $("status").className = `status ${st.connected ? "on" : "off"}`;
    $("status").textContent = !st.enabled ? "Off" : st.connected ? "Connected to Claude Code" : "Waiting for Claude Code";
    $("help").hidden = !st.enabled || st.connected;
    $("captureRow").hidden = st.capture;
    $("outdated").hidden = !st.outdated;
    $("outdated").textContent = st.outdated === "extension" ? `The Claude Code plugin (${st.plugin}) is newer than this extension (${st.version}): please update the extension.` : st.outdated === "plugin" ? `This extension (${st.version}) is newer than the Claude Code plugin (${st.plugin}): run /plugin marketplace update live-clawd, then /reload-plugins.` : "";
  }
  (async () => {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    url = tab && tab.url || "";
    await render();
    $("enabled").onchange = async (e) => {
      await ask("LiveSet", { enabled: e.target.checked });
      setTimeout(render, 300);
    };
    $("sound").onchange = (e) => ask("LiveSet", { sound: e.target.checked });
    $("muted").onchange = (e) => ask("LiveSet", { url, muted: e.target.checked });
    $("capture").onclick = async () => {
      await api.permissions.request({ origins: ["<all_urls>"] });
      await ask("CaptureAsked");
      render();
    };
  })();
})();
