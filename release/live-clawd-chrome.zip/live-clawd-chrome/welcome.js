(() => {
  // extension/src/api.js
  var api = globalThis.browser || globalThis.chrome;
  var FIREFOX = typeof globalThis.browser !== "undefined" && !!globalThis.browser.runtime.getBrowserInfo;

  // extension/src/welcome.js
  var $ = (id) => document.getElementById(id);
  var done = () => {
    $("ask").hidden = true;
    $("done").hidden = false;
  };
  api.permissions.contains({ origins: ["<all_urls>"] }).then((has) => {
    if (has) done();
  });
  async function checkConnection() {
    let st = null;
    try {
      st = await api.runtime.sendMessage({ cmd: "LiveGet", data: {} });
    } catch {
    }
    const on = !!(st && st.connected);
    $("status").className = `status ${on ? "on" : ""}`;
    $("status").textContent = on ? "Connected to Claude Code" : "Not connected to Claude Code yet";
    $("plugin").hidden = on;
  }
  checkConnection();
  setInterval(checkConnection, 2e3);
  $("allow").onclick = async () => {
    if (await api.permissions.request({ origins: ["<all_urls>"] })) done();
    api.runtime.sendMessage({ cmd: "CaptureAsked" });
  };
  $("skip").onclick = (e) => {
    e.preventDefault();
    api.runtime.sendMessage({ cmd: "CaptureAsked" });
    done();
  };
})();
