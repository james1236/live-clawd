(() => {
  // src/api.js
  var api = globalThis.browser || globalThis.chrome;
  var FIREFOX = typeof globalThis.browser !== "undefined" && !!globalThis.browser.runtime.getBrowserInfo;

  // src/welcome.js
  var $ = (id) => document.getElementById(id);
  var done = () => {
    $("ask").hidden = true;
    $("done").hidden = false;
  };
  api.permissions.contains({ origins: ["<all_urls>"] }).then((has) => {
    if (has) done();
  });
  $("allow").onclick = async () => {
    if (await api.permissions.request({ origins: ["<all_urls>"] })) done();
    api.runtime.sendMessage({ cmd: "CaptureAsked" });
  };
  $("skip").onclick = (e) => {
    e.preventDefault();
    api.runtime.sendMessage({ cmd: "CaptureAsked" });
    done();
  };
})();
